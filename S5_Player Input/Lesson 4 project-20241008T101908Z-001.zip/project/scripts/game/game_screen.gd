extends Node

class_name GameScreen

@export var map:Node

func _ready():
	map.add_child(load(GameManager.currentMapPath).instantiate())


func _on_pass_button_pressed():
	CommandDispatcher.PROCESS_COMMAND.emit(PassCommand.new())
