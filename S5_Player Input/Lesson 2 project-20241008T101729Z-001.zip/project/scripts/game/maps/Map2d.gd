extends TileMap

class_name Map2d

enum TerrainDataTypes { TerrainType }

func getTerrainDataForTile(layer, data, x, y):
	var tile:TileData = get_cell_tile_data(layer, Vector2i(x, y))

	if (tile != null):
		return tile.get_custom_data(TerrainDataTypes.keys()[data])
	else:
		return null
