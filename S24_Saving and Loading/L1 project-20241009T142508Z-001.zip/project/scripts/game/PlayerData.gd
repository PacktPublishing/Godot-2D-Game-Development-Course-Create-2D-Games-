
class_name PlayerData

signal GOLD_AMOUNT_CHANGED(value)
signal BANK_BALANCE_CHANGED(value)
signal HP_AMOUNT_CHANGED(value)
signal FOOD_AMOUNT_CHANGED(value)
signal DAMAGE_CHANGED(amount)
signal DEFENSE_CHANGED(amount)

enum EquipSlots { Weapon, Armor, Item }

var playerName:String

var timePassed:float:
	set(value):
		timePassed = value
		
		if (timePassed >= 1):
			timePassed -= 1
			bankBalance += bankBalance * bankInterestRate

var gold:int:
	set(value):
		gold = value
		GOLD_AMOUNT_CHANGED.emit(gold)


var bankBalance:float:
	set(value):
		bankBalance = value
		BANK_BALANCE_CHANGED.emit(bankBalance)

var food:float:
	set(value):
		food = value
		FOOD_AMOUNT_CHANGED.emit(food)

var inventory:Array[Item] = []

var equippedItems:Array[Item] = []

var strength:int:
	set(value):
		strength = value
		DAMAGE_CHANGED.emit(getBaseDamage())

var agility:int:
	set(value):
		agility = value
		DEFENSE_CHANGED.emit(getDefense())


var endurance:int
var luck:int

var maxHealth:int
var health:int:
	set(value):
		health = clamp(value, 0, maxHealth)
		HP_AMOUNT_CHANGED.emit(health)
		
var mana:int

var currentHealth:int
var currentMana:int

var bankInterestRate := 0.05

var xp:int:
	set(value):
		xp = value
		
		if (xp >= nextLevelGoal):
			level += 1
			xp -= nextLevelGoal
			nextLevelGoal = calculateNextLevelGoal()
			CommandDispatcher.DISPLAY_MESSAGE.emit("Level up!  Current level: %s" % level)
			strength += 1
			agility += 1
			endurance += 1
			luck += 1
			maxHealth += 10 + endurance


		print("%s -> %s" % [xp, nextLevelGoal])


var flags:Array[bool] = []

var level:int
var nextLevelGoal:int

func _init():
	playerName = "New Player"
	gold = 100
	maxHealth = 100
	food = 1000
	health = maxHealth
	level = 1
	nextLevelGoal = calculateNextLevelGoal()
	xp = 0
	
	inventory.clear()
	
	if (equippedItems.size() != EquipSlots.keys().size()):
		equippedItems.resize(EquipSlots.keys().size())

	if (flags.size() != GameManager.Flags.keys().size()):
		flags.resize(GameManager.Flags.keys().size())
		
	setFlag(GameManager.Flags.COMPLETED_HEALING_HERB_QUEST)


func giveItem(item):
	inventory.append(item)


func takeItem(item):
	if (item.itemType <= ItemDefinition.ItemTypes.Item):
		if (hasItemEquipped(item)):
			unequipItem(item)
		
	inventory.erase(item)


func isEquipped(item:Item) -> bool:
	return equippedItems[item.itemType] == item


func equipItem(item:Item):
	equippedItems[item.itemType] = item
	
	if (item.itemType == ItemDefinition.ItemTypes.Weapon):
		DAMAGE_CHANGED.emit(getBaseDamage())
		
	if (item.itemType == ItemDefinition.ItemTypes.Armor):
		DAMAGE_CHANGED.emit(getDefense())


func unequipItem(item:Item):
	equippedItems[item.itemType] = null
	
	if (item.itemType == ItemDefinition.ItemTypes.Weapon):
		DAMAGE_CHANGED.emit(getBaseDamage())
		
	if (item.itemType == ItemDefinition.ItemTypes.Armor):
		DAMAGE_CHANGED.emit(getDefense())


func hasItemEquipped(item:Item):
	return equippedItems[item.itemType] == item


func getMail(postalCode) -> Array[Mail]:
	var mail:Array[Mail] = []
	
	for item in inventory:
		if (item is Mail):
			if (item.destination == postalCode):
				mail.append(item)
	
	return mail


func setFlag(flag):
	flags[flag] = true


func clearFlag(flag):
	flags[flag] = false
	

func isFlagSet(flag) -> bool:
	return flags[flag]


func useItem(item:Item):
	item.use()
	
	if (item.itemType == ItemDefinition.ItemTypes.Healing):
		takeItem(item)


func calculateNextLevelGoal():
	return level * 10


func getBaseDamage() -> int:
	var damage = 0
	
	damage += strength / 10
	
	if (equippedItems[ItemDefinition.ItemTypes.Weapon] != null):
		damage += equippedItems[ItemDefinition.ItemTypes.Weapon].amount
	
	return damage


func getDefense() -> int:
	var defense = 0
	
	defense += agility / 10
	
	if (equippedItems[ItemDefinition.ItemTypes.Armor] != null):
		defense += equippedItems[ItemDefinition.ItemTypes.Armor].amount
	
	return defense
