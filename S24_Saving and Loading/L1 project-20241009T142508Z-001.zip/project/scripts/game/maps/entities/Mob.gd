extends Node2D

class_name Mob

@export var mobName := "Mob"
@export var health := 10
@export var defense := 10
@export var baseDamage := 1
@export var xpValue := 10
@export var combatString := "%s attacks you"
@export var hitString := "hits"
@export var missString := "and misses"

var player:Player
var hostile := false

func onReaction():
	if (player == null):
		CommandDispatcher.REGISTER_PLAYER.emit(self)


func attack(target:Mob):
	var result:String = initializeCombatString(target.mobName)
	var pointString:String = "point"
	
	# Dead mobs neither tell no tales nor attack players
	if (health == 0):
		return
	
	if (randi_range(1, 20) > target.defense):
		if (baseDamage != 1):
			pointString += "s"
			
		result += " and %s for %s %s of damage." % [hitString, baseDamage, pointString]
		
		target.onTakeDamage(baseDamage)
	else:
		result += " %s." % missString
	
	CommandDispatcher.DISPLAY_MESSAGE.emit(result)
	
	if (target.health == 0):
		target.onDie()


func initializeCombatString(target) -> String:
	return combatString % mobName


func interact():
	CommandDispatcher.DISPLAY_MESSAGE.emit("The %s does not respond." % mobName)


func onTakeDamage(amount):
	health -= amount


func onDie():
	CommandDispatcher.DISPLAY_MESSAGE.emit("%s has died!" % mobName)
	GameManager.player.xp += xpValue
	queue_free()


func onDamageChanged(amount):
	baseDamage = amount


func onDefenseChanged(amount):
	defense = amount
