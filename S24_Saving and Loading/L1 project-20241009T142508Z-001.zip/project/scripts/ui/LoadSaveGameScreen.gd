extends PanelContainer

class_name LoadSaveGameScreen

@export var header:Label
@export var saveSlots:VBoxContainer

func _on_back_button_pressed():
	pass # Replace with function body.
