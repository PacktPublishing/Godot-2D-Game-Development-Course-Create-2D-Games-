extends PanelContainer

class_name SaveSlot

@export var playerStats:Label
@export var mapName:Label
@export var timestamp:Label

@export var loadButton:Button
@export var saveButton:Button
@export var deleteButton:Button

func _on_load_button_pressed():
	pass # Replace with function body.


func _on_save_button_pressed():
	pass # Replace with function body.


func _on_delete_button_pressed():
	pass # Replace with function body.
