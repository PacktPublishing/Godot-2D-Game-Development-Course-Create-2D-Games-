extends PanelContainer

class_name LoadSaveGameScreen

@export var header:Label
@export var saveSlots:VBoxContainer
@export var confirmDialog:ConfirmYesNoDialog

func _ready():
	for slot in saveSlots.get_children():
		slot.LOAD_SLOT.connect(onSlotLoadRequest)
		slot.SAVE_SLOT.connect(onSlotSaveRequest)
		slot.DELETE_SLOT.connect(onSlotDeleteRequest)

	#	slot.updateMetadata(GameManager.loadGameMetadata(slot.get_index()))
		
		#if (!FileAccess.file_exists("%s%s" % [GameManager.getSaveSlotPath(slot.get_index()), GameManager.SAVE_METADATA_EXT])):
			#slot.deleteButton.hide()


func _on_back_button_pressed():
	pass # Replace with function body.


func onSlotLoadRequest(slot):
	pass


func onSlotSaveRequest(slot):
	if (FileAccess.file_exists("%s%s" % [GameManager.getSaveSlotPath(slot), GameManager.SAVE_METADATA_EXT])):
		showConfirmDialog("Overwrite Slot %s?" % (slot + 1), saveGame.bind(slot))
	else:
		saveGame(slot)


func onSlotDeleteRequest(slot):
	pass


func showConfirmDialog(text, callback):
	confirmDialog.confirmationText.text = text
	confirmDialog.yesCallback = callback
	confirmDialog.show()


func saveGame(slot):
	var metadata = GameManager.saveGame(slot)

	saveSlots.get_child(slot).updateMetadata(metadata)
	saveSlots.get_child(slot).deleteButton.show()
