
class_name Item

var itemName:String
var itemType:ItemDefinition.ItemTypes
var amount:int
var sellPrice:int

func _init(itemDefinition:ItemDefinition):
	itemName = itemDefinition.itemName
	itemType = itemDefinition.itemType
	amount = itemDefinition.amount
	sellPrice = itemDefinition.price * itemDefinition.markdown


func use():
	if (itemType == ItemDefinition.ItemTypes.Healing):
		GameManager.player.health += amount
		CommandDispatcher.DISPLAY_MESSAGE.emit("You regained %s health." % amount)


func saveData(saveFile):
	saveFile.store_pascal_string(itemName)
	saveFile.set_8(amount)
	saveFile.set_8(sellPrice)
