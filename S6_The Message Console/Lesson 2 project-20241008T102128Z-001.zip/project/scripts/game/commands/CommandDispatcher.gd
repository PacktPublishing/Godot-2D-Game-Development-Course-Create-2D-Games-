extends Node

signal PROCESS_COMMAND(command)
signal WAIT_FOR_COMMAND
signal PAUSE_PROCESSOR

signal PLAYER_MOVE(direction)

signal DISPLAY_MESSAGE(message)
signal DISPLAY_COMMAND_PROMPT
signal DISPLAY_CLEAR
