extends Control

class_name DialogContainer

@export var shopUI:Control
@export var confirmDialog:Control
@export var characterInfoDialog:Control
@export var equipDialog:Control

func _ready():
	CommandDispatcher.SHOW_SHOP_UI.connect(onShowShopUI)
	CommandDispatcher.SHOW_CONFIRMATION_DIALOG.connect(onConfirmDialogRequest)
	CommandDispatcher.CLOSE_DIALOG.connect(onCloseRequest)
	CommandDispatcher.SHOW_CHARACTER_INFO_DIALOG.connect(onCharacterInfoDialogRequest)
	CommandDispatcher.SHOW_EQUIP_DIALOG.connect(onEquipItemRequest)


func onShowShopUI(shopKeeper, inventory, filter):
	shopUI.shopNameLabel.text = shopKeeper.shopName
	shopUI.shopInventoryItems = inventory
	shopUI.mode = ShopUI.Modes.Buy
	shopUI.filter = filter
	shopUI.LEFT_SHOP.connect(shopKeeper.onLeftShop.bind(shopUI))
	shopUI.playerGoldAmount.text = str(GameManager.player.gold)
	shopUI.show()
	show()


func onCloseRequest(caller):
	caller.hide()
	hide()
	CommandDispatcher.WAIT_FOR_COMMAND.emit()


func onConfirmDialogRequest(text, callback):
	confirmDialog.confirmTextLabel.text = text
	confirmDialog.yesCallback = callback
	confirmDialog.show()


func onCharacterInfoDialogRequest():
	CommandDispatcher.PAUSE_PROCESSOR.emit()
	characterInfoDialog.updateDisplay()
	characterInfoDialog.show()
	show()


func onEquipItemRequest(filter):
	CommandDispatcher.PAUSE_PROCESSOR.emit()
	equipDialog.filter = filter
	equipDialog.updateDisplay()
	equipDialog.show()
	show()
