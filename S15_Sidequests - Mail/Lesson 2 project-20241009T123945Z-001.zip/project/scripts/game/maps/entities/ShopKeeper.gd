extends Mob2D

class_name ShopKeeper

enum Responses { Yes, No }

@export var shopName:String
@export var inventory:Array[ItemDefinition]
@export var buybackFilter:ItemDefinition.ItemTypes
@export var mailman:bool
@export var mailQuestChance := 100
@export var mail:MailDefinition

func _ready():
	var mail:Mail = mail.clone()
	print("whatever")

func interact():
	CommandDispatcher.DISPLAY_PROMPT.emit("**%s**: Would you like to see my wares?\n\n" % shopName, Responses.keys(), onResponse)


func onResponse(selected):
	match(selected):
		Responses.Yes:
			CommandDispatcher.SHOW_SHOP_UI.emit(self, inventory, buybackFilter)
		Responses.No:
			CommandDispatcher.DISPLAY_MESSAGE.emit("Come back later, then.")
			CommandDispatcher.WAIT_FOR_COMMAND.emit()


func onLeftShop(shopUI):
	shopUI.LEFT_SHOP.disconnect(onLeftShop)
	
	if (mailman and randi_range(0, 100) <= mailQuestChance):
		CommandDispatcher.PAUSE_PROCESSOR.emit()
		CommandDispatcher.DISPLAY_PROMPT.emit("Would you deliver a package to %s for me?\n\n" % "cityname", Responses.keys(), onMailResponse)


func onMailResponse(response):
	CommandDispatcher.DISPLAY_MESSAGE.emit("Appreciate it.")
