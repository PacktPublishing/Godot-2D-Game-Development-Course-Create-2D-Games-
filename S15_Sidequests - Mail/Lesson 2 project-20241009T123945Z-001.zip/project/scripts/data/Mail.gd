extends Item

class_name Mail

var destination:MailDefinition.Towns

func _init(itemDefinition:MailDefinition):
	super._init(itemDefinition)
	
	destination = itemDefinition.destination
