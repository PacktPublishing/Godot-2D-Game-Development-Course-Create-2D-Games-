extends ItemDefinition

class_name MailDefinition

enum Towns { NO_ADDRESS, StarterTown, SecondCity }

@export var destination:Towns

func clone() -> Mail:
	return Mail.new(self)
