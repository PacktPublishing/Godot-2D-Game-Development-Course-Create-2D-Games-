extends Node

var defaultMapPath:String

var currentMapPath

func startNewGame():
	currentMapPath = defaultMapPath
