extends Node

class_name GameScreen

@export var map:Node

var menuOpen:bool

func _ready():
	CommandDispatcher.LOAD_MAP.emit(GameManager.currentMap, GameManager.player.mapPosition, GameManager.player.mapFacing)
	CommandDispatcher.LOAD_SAVE_MENU_CLOSED.connect(
		func():
			menuOpen = false
			CommandDispatcher.WAIT_FOR_COMMAND.emit()
	)


func _unhandled_key_input(event):
	if Input.is_action_just_pressed("load_screen") and !menuOpen:
		openLoadSaveMenu(LoadSaveGameScreen.Modes.Load)
	
	if Input.is_action_just_pressed("save_screen") and !menuOpen:
		openLoadSaveMenu(LoadSaveGameScreen.Modes.Save)


func openLoadSaveMenu(mode):
	var loadSaveScene
	
	CommandDispatcher.PAUSE_PROCESSOR.emit()
	loadSaveScene = load("res://scenes/ui/load_save_game_screen.tscn").instantiate()
	get_tree().root.add_child(loadSaveScene)
	
	loadSaveScene.mode = mode
	loadSaveScene.caller = self
	
	menuOpen = true
