extends Node2D

class_name Chest

@export var sprite:Sprite2D
@export var condition:Condition

func open():
	var amount = randi_range(10, 100)

	GameManager.player.gold += amount
	CommandDispatcher.DISPLAY_MESSAGE.emit("You find %s gold." % amount)
	
	if (condition.evaluate()):
		GameManager.player.giveItem(condition.item.clone())
		CommandDispatcher.DISPLAY_MESSAGE.emit("You find the Legendary Sword of Questor!")
	
	queue_free()
