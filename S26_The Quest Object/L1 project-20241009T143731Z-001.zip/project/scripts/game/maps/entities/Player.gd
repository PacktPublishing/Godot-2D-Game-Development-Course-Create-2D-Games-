extends Mob2D

class_name Player

@export var camera:Camera2D

func _ready():
	GameManager.player.FOOD_AMOUNT_CHANGED.connect(onFoodAmountChanged)
	GameManager.player.DAMAGE_CHANGED.connect(onDamageChanged)
	GameManager.player.DEFENSE_CHANGED.connect(onDefenseChanged)
	health = GameManager.player.health


func wouldCollideAt(destination):
	if (super.wouldCollideAt(destination)):
		return true
	else:
		return false

func initializeCombatString(target) -> String:
	return combatString % target


func attack(target:Mob):
	super.attack(target)
	target.hostile = true


func onTakeDamage(amount):
	super.onTakeDamage(amount)
	GameManager.player.health = health


func onDie():
	CommandDispatcher.PLAYER_DIED.emit()


func onFoodAmountChanged(amount):
	if (amount == 0):
		onDie()
