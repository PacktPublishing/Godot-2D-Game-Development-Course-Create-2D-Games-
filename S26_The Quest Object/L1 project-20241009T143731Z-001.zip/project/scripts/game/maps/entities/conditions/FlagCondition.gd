extends Condition

class_name FlagCondition

enum Checks { Set, Not_Set }

@export var flag:GameManager.Flags
@export var checkToPerform:Checks

func evaluate() -> bool:
	if checkToPerform == Checks.Set:
		return GameManager.player.isFlagSet(flag)
	else:
		return !GameManager.player.isFlagSet(flag)
