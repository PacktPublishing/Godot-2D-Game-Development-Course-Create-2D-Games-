extends Resource

class_name Condition

func evaluate() -> bool:
	return true
