extends Condition

class_name HasItemCondition

enum Checks { Has_Item, Does_Not_Have_Item }

@export var item:ItemDefinition
@export var checkToPerform:Checks

func evaluate() -> bool:
	if checkToPerform == Checks.Has_Item:
		return GameManager.player.hasItem(item)
	else:
		return !GameManager.player.hasItem(item)
