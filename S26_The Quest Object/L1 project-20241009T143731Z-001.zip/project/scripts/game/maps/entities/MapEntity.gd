extends Area2D

class_name MapEntity

@export var condition:Condition

func execute(target):
	print("MapEntity.execute(%s)" % target.name)


func _on_area_entered(area):
	if (condition == null):
		execute(area.get_parent())
	else:
		if (condition.evaluate()):
			execute(area.get_parent())
