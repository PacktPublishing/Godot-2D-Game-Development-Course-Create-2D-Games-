extends Node

const SAVE_METADATA_TAG:String = "Save Metadata"
const SAVE_METADATA_PLAYER_STATS:String = "player_stats"
const EMPTY_METADATA_LABEL:String = "Empty Slot"
const SAVE_METADATA_MAP:String = "map"
const SAVE_METADATA_DATE_TIME:String = "date_time"
const SAVE_METADATA_EXT:String = ".svm"
const SAVE_DATA_EXT:String = ".sav"
const SAVE_PATH:String = "user://%s%s"
const SLOT_NAME:String = "save_slot_"

enum Flags { COMPLETED_HEALING_HERB_QUEST }

var startMap:String = "res://scenes/game/maps/world_map.tscn"

var currentMap:String
var currentMapName:String

var player:PlayerData = PlayerData.new()

func startNewGame():
	currentMap = startMap
	player = PlayerData.new()


func getSaveSlotPath(slot) -> String:
	return SAVE_PATH % [SLOT_NAME, slot]


func saveGame(slot) -> SaveGameMetaData:
	var metadata = saveMetaData(slot)
	var saveFile = FileAccess.open(getSaveSlotPath(slot) + SAVE_DATA_EXT, FileAccess.WRITE)

	player.saveData(saveFile)

	saveFile.store_pascal_string(currentMap)
	
	return metadata


func saveMetaData(slot) -> SaveGameMetaData:
	var metadata = SaveGameMetaData.new()
	var metadataFile = ConfigFile.new()
	var dateTime = Time.get_datetime_dict_from_system()
	
	metadata.playerStats = "%s - %s" % [player.playerName,player.level]
	metadata.map = currentMapName
	metadata.dateTime = "%s/%s/%s %s:%s:%s" % [
		dateTime["month"], 
		dateTime["day"], 
		dateTime["year"], 
		dateTime["hour"], 
		dateTime["minute"], 
		dateTime["second"]]
		
	metadataFile.set_value(SAVE_METADATA_TAG, SAVE_METADATA_PLAYER_STATS, metadata.playerStats)
	metadataFile.set_value(SAVE_METADATA_TAG, SAVE_METADATA_MAP, metadata.map)
	metadataFile.set_value(SAVE_METADATA_TAG, SAVE_METADATA_DATE_TIME, metadata.dateTime)
	
	metadataFile.save("%s%s" % [getSaveSlotPath(slot), SAVE_METADATA_EXT])
	
	return metadata


class SaveGameMetaData:
	var playerStats:String = EMPTY_METADATA_LABEL
	var map:String
	var dateTime:String


func deleteSaveGame(slot) -> SaveGameMetaData:
	var metadata = SaveGameMetaData.new()
	var saveFilePath = "%s%s" % [getSaveSlotPath(slot), SAVE_DATA_EXT]
	var saveFileMetadataPath = "%s%s" % [getSaveSlotPath(slot), SAVE_METADATA_EXT]

	if (FileAccess.file_exists(saveFilePath)):
		DirAccess.remove_absolute(saveFilePath)
	
	if (FileAccess.file_exists(saveFileMetadataPath)):
		DirAccess.remove_absolute(saveFileMetadataPath)
	
	return metadata


func loadGameMetadata(slot) -> SaveGameMetaData:
	var metadata = SaveGameMetaData.new()
	var metadataFile = ConfigFile.new()
	
	var status = metadataFile.load("%s%s" % [getSaveSlotPath(slot), SAVE_METADATA_EXT])
	
	if (status == OK):
		metadata.playerStats = metadataFile.get_value(SAVE_METADATA_TAG, SAVE_METADATA_PLAYER_STATS)
		metadata.map = metadataFile.get_value(SAVE_METADATA_TAG, SAVE_METADATA_MAP)
		metadata.dateTime = metadataFile.get_value(SAVE_METADATA_TAG, SAVE_METADATA_DATE_TIME)
	
	return metadata


func loadGame(slot):
	var saveFile = FileAccess.open(getSaveSlotPath(slot) + SAVE_DATA_EXT, FileAccess.READ)

	player.loadData(saveFile)

	currentMap = saveFile.get_pascal_string()

