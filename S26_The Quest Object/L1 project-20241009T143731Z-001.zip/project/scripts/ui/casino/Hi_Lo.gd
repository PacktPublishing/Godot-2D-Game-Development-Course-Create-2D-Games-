extends Control

class_name CasinoGameHiLo

signal LEAVE_CASINO

@export_group("Controls")
@export var casinoName:Label
@export var playfield:HBoxContainer
@export var controlPanel:CasinoControlPanel
@export var confirmDialog:ConfirmYesNoDialog
@export var playerGoldValueLabel:Label
@export var payoutGoldValueLabel:Label
@export var howToPlayDialog:Control
@export var confetti:GPUParticles2D

@export_group("Betting")
@export var payoutMultiplier := 1.5

enum GuessTypes { Higher, Lower }

var rng:RandomNumberGenerator = RandomNumberGenerator.new()
var playingCardPrefab = preload("res://scenes/game/casino/playing_card.tscn")

var payout:int:
	set(value):
		payout = value
		payoutGoldValueLabel.text = str(payout)

var deck:Dictionary = {}

var guess:GuessTypes

func _ready():
	GameManager.player.GOLD_AMOUNT_CHANGED.connect(onPlayerGoldAmountChanged)
	playerGoldValueLabel.text = str(GameManager.player.gold)
	promptPlayerForInstructions()


func onPlayerGoldAmountChanged(value):
	playerGoldValueLabel.text = str(value)


func promptPlayerForInstructions():
	confirmDialog.noButton.pressed.connect(startGame)
	confirmDialog.confirmTextLabel.text = "Do you want to see the instructions?"
	confirmDialog.yesCallback = showInstructions
	confirmDialog.show()


func startGame():
	controlPanel.setStatusText("Place initial bet:")
	controlPanel.showBettingControls()


func showInstructions():
	howToPlayDialog.show()


func _on_how_to_play_ok_button_pressed():
	howToPlayDialog.hide()
	confirmDialog.noButton.pressed.disconnect(startGame)
	startGame()


func _on_higher_button_pressed():
	guess = GuessTypes.Higher
	resolveGuess()


func _on_lower_button_pressed():
	guess = GuessTypes.Lower
	resolveGuess()


func _on_guess_again_button_pressed():
	controlPanel.hideAllControls()
	payout += controlPanel.betEntry.value * payoutMultiplier
	dealCard()


func _on_stop_guessing_button_pressed():
	controlPanel.setStatusText("OK, here's your winnings.")
	GameManager.player.gold += payout
	payout = 0
	clearTable()
	controlPanel.hideAllControls()
	await get_tree().create_timer(1, true).timeout
	controlPanel.statusText.text = "Place your bet:"
	controlPanel.showBettingControls()


func _on_place_bet_button_pressed():
	payout = controlPanel.betEntry.value * payoutMultiplier
	GameManager.player.gold -= controlPanel.betEntry.value
	controlPanel.hideAllControls()
	controlPanel.setStatusText("")
	shuffleDeck()
	await get_tree().create_timer(1, true).timeout
	dealCard()
	await get_tree().create_timer(1, true).timeout
	dealCard()


func _on_leave_button_pressed():
	confirmDialog.confirmTextLabel.text = "Leave %s?" % casinoName.text
	confirmDialog.yesCallback = func():
		confirmDialog.hide()
		LEAVE_CASINO.emit()
		queue_free()
		
	confirmDialog.show()


func shuffleDeck():
	controlPanel.setStatusText("Shuffling Deck...")
	deck.clear()

	for suit in PlayingCard.Suits.values():
		deck[suit] = []
		
		for face in PlayingCard.Faces.values():
			if (face != PlayingCard.Faces.MISC):
				deck[suit].append(face)


func dealNewCardFromDeck():
	var card = playingCardPrefab.instantiate() as PlayingCard
	
	var suit = deck.keys()[rng.randi_range(0, deck.keys().size() - 1)]
	var face = deck[suit][rng.randi_range(0, deck[suit].size() - 1)]
	
	deck[suit].erase(face)
	
	if (deck[suit].size() == 0):
		deck.erase(suit)
		
	card.suit = suit
	card.face = face
	
	return card


func dealCard():
	var card = dealNewCardFromDeck()
	
	controlPanel.setStatusText("The dealer deals a new card...")
	playfield.add_child(card)

	if (playfield.get_child_count() == 10):
		payout *= 2
	
	if (playfield.get_child_count() > 1):
		card.flip()
		await get_tree().create_timer(1, true).timeout
		controlPanel.setStatusText("Well, what's your guess?")
		controlPanel.showGuessingControls()


func resolveGuess():
	var previousCard:PlayingCard = playfield.get_child(playfield.get_child_count() - 2)
	var currentCard:PlayingCard = playfield.get_child(playfield.get_child_count() - 1)
	
	var previousCardValue
	var currentCardValue
	
	var won = false
	var shouldClearTable = false

	if (previousCard.face == PlayingCard.Faces.Ace):
		previousCardValue = PlayingCard.Faces.King + 1
	else:
		previousCardValue = previousCard.face
	
	if (currentCard.face == PlayingCard.Faces.Ace):
		currentCardValue = PlayingCard.Faces.King + 1
	else:
		currentCardValue = currentCard.face
		
	if (guess == GuessTypes.Higher):
		if (currentCardValue > previousCardValue):
			won = true
	else:
		if (currentCardValue < previousCardValue):
			won = true
	
	if (!won):
		if (randi_range(0, 100) <= GameManager.player.luck):
			if (guess == GuessTypes.Higher and previousCard.face != PlayingCard.Faces.Ace):
				if (previousCard.face == PlayingCard.Faces.King):
					currentCard.face = PlayingCard.Faces.Ace
				else:
					currentCard.face = previousCard.face + 1
				won = true
			
			if (guess == GuessTypes.Lower and previousCard.face != PlayingCard.Faces.Two):
				currentCard.face = previousCard.face - 1
				won = true
	
	controlPanel.hideAllControls()
	currentCard.flip()
	
	controlPanel.setStatusText("")
	
	await get_tree().create_timer(1, true).timeout
	
	if (won):
		if (playfield.get_child_count() == 10):
			controlPanel.setStatusText("Jackpot!!")
			confetti.emitting = true
			GameManager.player.gold += payout
			shouldClearTable = true
			payout = 0
			await get_tree().create_timer(1, true).timeout
		else:
			controlPanel.setStatusText("Well done.  Do you want to keep going?")
			controlPanel.showPushOrStopControls()
	else:
		controlPanel.setStatusText("Better luck next time.")
		shouldClearTable = true
		payout = 0
		await get_tree().create_timer(1, true).timeout

	if (shouldClearTable):
		clearTable()
		controlPanel.hideAllControls()
		controlPanel.setStatusText("Place your bet:")
		controlPanel.showBettingControls()


func clearTable():
	for card in playfield.get_children():
		card.queue_free()
