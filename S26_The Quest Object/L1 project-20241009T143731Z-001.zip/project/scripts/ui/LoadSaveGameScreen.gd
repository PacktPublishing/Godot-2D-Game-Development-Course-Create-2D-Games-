extends PanelContainer

class_name LoadSaveGameScreen

enum Modes { Load, Save }

@export var header:Label
@export var saveSlots:VBoxContainer
@export var confirmDialog:ConfirmYesNoDialog

var mode:
	set(value):
		mode = value
		
		header.text = "%s Game" % Modes.keys()[mode]
		
		for slot in saveSlots.get_children():
			if (mode == Modes.Load):
				slot.loadButton.show()
				slot.saveButton.hide()
			
			if (mode == Modes.Save):
				slot.loadButton.hide()
				slot.saveButton.show()

			if (slot.playerStats.text == GameManager.EMPTY_METADATA_LABEL):
				slot.loadButton.hide()
				slot.deleteButton.hide()
				
var caller

func _ready():
	for slot in saveSlots.get_children():
		slot.LOAD_SLOT.connect(onSlotLoadRequest)
		slot.SAVE_SLOT.connect(onSlotSaveRequest)
		slot.DELETE_SLOT.connect(onSlotDeleteRequest)

		slot.updateMetadata(GameManager.loadGameMetadata(slot.get_index()))
		
		if (!FileAccess.file_exists("%s%s" % [GameManager.getSaveSlotPath(slot.get_index()), GameManager.SAVE_METADATA_EXT])):
			slot.deleteButton.hide()


func _on_back_button_pressed():
	queue_free()
	CommandDispatcher.LOAD_SAVE_MENU_CLOSED.emit()


func onSlotLoadRequest(slot):
	showConfirmDialog("Load Slot %s?" % (slot + 1), loadGame.bind(slot))


func onSlotSaveRequest(slot):
	if (FileAccess.file_exists("%s%s" % [GameManager.getSaveSlotPath(slot), GameManager.SAVE_METADATA_EXT])):
		showConfirmDialog("Overwrite Slot %s?" % (slot + 1), saveGame.bind(slot))
	else:
		saveGame(slot)


func onSlotDeleteRequest(slot):
	if (FileAccess.file_exists("%s%s" % [GameManager.getSaveSlotPath(slot), GameManager.SAVE_METADATA_EXT])):
		showConfirmDialog("Delete Save at Slot %s?" % (slot + 1), deleteGame.bind(slot))


func showConfirmDialog(text, callback):
	confirmDialog.confirmTextLabel.text = text
	confirmDialog.yesCallback = callback
	confirmDialog.show()


func saveGame(slot):
	var metadata = GameManager.saveGame(slot)

	saveSlots.get_child(slot).updateMetadata(metadata)
	saveSlots.get_child(slot).deleteButton.show()


func deleteGame(slot):
	var metadata = GameManager.deleteSaveGame(slot)

	saveSlots.get_child(slot).updateMetadata(metadata)
	saveSlots.get_child(slot).deleteButton.hide()


func loadGame(slot):
	GameManager.loadGame(slot)
	Loader.loadScene(caller, "res://scenes/game_screen.tscn")
	queue_free()
