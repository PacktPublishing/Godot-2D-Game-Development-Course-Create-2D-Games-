extends PanelContainer

class_name SaveSlot

signal LOAD_SLOT(slot)
signal SAVE_SLOT(slot)
signal DELETE_SLOT(slot)

@export var playerStats:Label
@export var mapName:Label
@export var timestamp:Label

@export var loadButton:Button
@export var saveButton:Button
@export var deleteButton:Button

func _on_load_button_pressed():
	LOAD_SLOT.emit(get_index())


func _on_save_button_pressed():
	SAVE_SLOT.emit(get_index())


func _on_delete_button_pressed():
	DELETE_SLOT.emit(get_index())


func updateMetadata(metadata):
	playerStats.text = metadata.playerStats
	mapName.text = metadata.map
	timestamp.text = metadata.dateTime
	
	if (metadata.playerStats == GameManager.EMPTY_METADATA_LABEL):
		loadButton.hide()
		deleteButton.hide()
