extends PanelContainer

class_name CharacterInfoDialog

@export var strength:Label
@export var agility:Label
@export var endurance:Label
@export var luck:Label

@export var health:Label
@export var mana:Label

@export var inventory:VBoxContainer

func updateDisplay():
	var label:Label
	
	strength.text = str(GameManager.player.strength)
	agility.text = str(GameManager.player.agility)
	endurance.text = str(GameManager.player.endurance)
	luck.text = str(GameManager.player.luck)
	
	health.text = "%s/%s" % [GameManager.player.health, GameManager.player.health]
	mana.text = "%s/%s" % [GameManager.player.currentMana, GameManager.player.mana]
	
	for item in inventory.get_children():
		item.queue_free()
		
	for item in GameManager.player.inventory:
		label = Label.new()
		label.text = item.itemName
		
		inventory.add_child(label)


func _on_ok_button_pressed():
	CommandDispatcher.CLOSE_DIALOG.emit(self, true)
