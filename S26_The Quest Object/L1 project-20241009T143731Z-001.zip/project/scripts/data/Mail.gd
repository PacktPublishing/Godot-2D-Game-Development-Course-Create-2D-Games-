extends Item

class_name Mail

var destination:MailDefinition.Towns:
	set(value):
		destination = value
		itemName = "%s Mail" % MailDefinition.TownNames[destination]


func _init(itemDefinition:MailDefinition = null):
	if (itemDefinition == null):
		return
		
	super._init(itemDefinition)
	
	destination = itemDefinition.destination


func saveData(saveFile):
	super.saveData(saveFile)
	saveFile.set_8(destination)

	
func loadData(saveFile):
	super.loadData(saveFile)
	destination = saveFile.get_pascal_string()
