extends Resource

class_name ItemDefinition

enum ItemTypes { Item, Weapon, Armor, Mail, Healing, Quest }

@export var itemType:ItemTypes
@export var itemName:String
@export var amount:int
@export var price:int
@export var markdown:float = 0.75


func clone() -> Item:
	return Item.new(self)
