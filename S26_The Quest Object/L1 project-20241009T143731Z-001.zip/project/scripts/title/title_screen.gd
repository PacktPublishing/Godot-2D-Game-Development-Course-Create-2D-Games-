extends Control

func _on_new_game_button_pressed():
	GameManager.startNewGame()
	
	Loader.loadScene(self, "res://scenes/game_screen.tscn")



func _on_load_game_button_pressed():
	var loadSaveScene = load("res://scenes/ui/load_save_game_screen.tscn").instantiate()
	get_tree().root.add_child(loadSaveScene)
	
	loadSaveScene.mode = LoadSaveGameScreen.Modes.Load
	loadSaveScene.caller = self


func _on_quit_button_pressed():
	get_tree().quit()
