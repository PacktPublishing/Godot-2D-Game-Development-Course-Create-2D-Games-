extends Control

class_name UI

func _ready():
	CommandDispatcher.SHOW_SHOP_UI.connect(_on_shop_ui)


func _on_pass_button_pressed():
	CommandDispatcher.PROCESS_COMMAND.emit(PassCommand.new())


func _on_speak_button_pressed():
	CommandDispatcher.PROCESS_COMMAND.emit(SpeakCommand.new())


func _on_shop_ui(shopName, inventory):
	print("Opening %s's shop." % shopName)
