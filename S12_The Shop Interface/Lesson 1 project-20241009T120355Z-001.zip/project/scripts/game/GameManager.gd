extends Node

var startMap:String = "res://scenes/game/maps/world_map.tscn"

var currentMap:String

func startNewGame():
	currentMap = startMap
