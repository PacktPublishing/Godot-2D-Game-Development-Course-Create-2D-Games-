extends Resource

class_name ItemDefinition

enum ItemTypes { Item, Weapon, Armor }

@export var itemType:ItemTypes
@export var itemName:String
@export var price:int
