extends MarginContainer

class_name ShopItemEntry

@export var itemName:Label
@export var itemPrice:Label
@export var sellCheckbox:CheckBox
