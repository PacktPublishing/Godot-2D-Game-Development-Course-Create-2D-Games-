extends PanelContainer

class_name ShopUI

var itemEntryPrefab = preload("res://scenes/ui/shops/shop_item_entry.tscn")

@export var shopNameLabel:Label
@export var inventoryContainerContents:VBoxContainer
@export var buySellTotalAmount:Label
@export var playerGoldAmount:Label

var buyTotalsLabelOriginalTextColor

func _ready():
	buyTotalsLabelOriginalTextColor = buySellTotalAmount.get_theme_color("font_color")


var shopInventoryItems:Array[ItemDefinition]:
	set(value):
		var itemEntry
		
		shopInventoryItems = value
		
		for item in inventoryContainerContents.get_children():
			item.queue_free()
		
		for itemDefinition in shopInventoryItems:
			itemEntry = itemEntryPrefab.instantiate() as ShopItemEntry
			
			itemEntry.itemName.text = itemDefinition.itemName
			itemEntry.itemPrice.text = str(itemDefinition.price)
			
			itemEntry.itemQuantity.value_changed.connect(onSpinboxValueChanged)
			
			inventoryContainerContents.add_child(itemEntry)


func _on_buy_button_pressed():
	CommandDispatcher.SHOW_CONFIRMATION_DIALOG.emit("Buy %s items for a total of %s gold?" % [tallyBuyQuantities(), buySellTotalAmount.text], buyItems)


func _on_clear_button_pressed():
	CommandDispatcher.SHOW_CONFIRMATION_DIALOG.emit("Clear intended purchases?", clearPurchases)


func _on_leave_button_pressed():
	CommandDispatcher.SHOW_CONFIRMATION_DIALOG.emit("Leave %s?" % shopNameLabel.text, leaveShop)


func leaveShop():
	CommandDispatcher.DISPLAY_MESSAGE.emit("Thank you, come again!")
	CommandDispatcher.CLOSE_DIALOG.emit(self)


func onSpinboxValueChanged(value):
	updateBuyTotalsDisplay()


func updateBuyTotalsDisplay():
	var total = tallyTotalBuyPrice()
	
	buySellTotalAmount.text = str(total)


func tallyTotalBuyPrice() -> int:
	var total = 0
	
	for item in inventoryContainerContents.get_children():
		total += int(item.itemPrice.text) * item.itemQuantity.value
	
	return total


func tallyBuyQuantities() -> int:
	var total = 0
	
	for item in inventoryContainerContents.get_children():
		total += item.itemQuantity.value

	return total


func buyItems():
	var totalGold = tallyTotalBuyPrice()
	
	if (GameManager.player.gold >= totalGold):
		GameManager.player.gold -= totalGold
		
		for item in inventoryContainerContents.get_children():
			for purchase in range(item.itemQuantity.value):
				GameManager.player.giveItem(shopInventoryItems[item.get_index()].clone())
		
		clearPurchases()
		
		playerGoldAmount.text = str(GameManager.player.gold)


func clearPurchases():
	for item in inventoryContainerContents.get_children():
		item.itemQuantity.apply()
		item.itemQuantity.value = 0
