
class_name PlayerData

var playerName:String
var gold:int
var inventory:Array = []

func _init():
	playerName = "New Player"
	gold = 100
	
	inventory.clear()


func giveItem(item:ItemDefinition):
	inventory.append(Item.new(item.itemName, item.itemType))
