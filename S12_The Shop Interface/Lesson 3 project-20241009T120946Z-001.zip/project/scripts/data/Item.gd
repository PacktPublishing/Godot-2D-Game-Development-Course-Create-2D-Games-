
class_name Item

var itemName:String
var itemType:ItemDefinition.ItemTypes

func _init(n, type):
	itemName = n
	itemType = type
