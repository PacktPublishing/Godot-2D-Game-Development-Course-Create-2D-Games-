extends PanelContainer

class_name ShopUI

var itemEntryPrefab = preload("res://scenes/ui/shops/shop_item_entry.tscn")

@export var shopNameLabel:Label
@export var inventoryContainer:VBoxContainer
@export var totalGoldValue:Label
@export var playerGoldValue:Label

var buyTotalsLabelOriginalTextColor

func _ready():
	buyTotalsLabelOriginalTextColor = totalGoldValue.get_theme_color("font_color")


var shopInventoryItems:Array[ItemDefinition]:
	set(value):
		var itemEntry
		
		shopInventoryItems = value
		
		for item in inventoryContainer.get_children():
			item.queue_free()
		
		for itemDefinition in shopInventoryItems:
			itemEntry = itemEntryPrefab.instantiate() as ShopItemEntry
			
			itemEntry.itemName.text = itemDefinition.itemName
			itemEntry.itemPrice.text = str(itemDefinition.price)
			
			itemEntry.itemQuantity.value_changed.connect(onSpinboxValueChanged)
			
			inventoryContainer.add_child(itemEntry)



func _on_buy_button_pressed():
	pass # Replace with function body.


func _on_clear_button_pressed():
	for item in inventoryContainer.get_children():
		item.itemQuantity.apply()
		item.itemQuantity.value = 0


func _on_leave_button_pressed():
	CommandDispatcher.SHOW_CONFIRMATION_DIALOG.emit("Leave %s?" % shopNameLabel.text, leaveShop)


func leaveShop():
	CommandDispatcher.DISPLAY_MESSAGE.emit("Thank you, come again!")
	CommandDispatcher.CLOSE_DIALOG.emit(self)


func onSpinboxValueChanged(value):
	updateBuyTotalsDisplay()


func updateBuyTotalsDisplay():
	var total = tallyBuyPriceValues()
	
	totalGoldValue.text = str(total)


func tallyBuyPriceValues() -> int:
	var total = 0
	
	for item in inventoryContainer.get_children():
		total += int(item.itemPrice.text) * item.itemQuantity.value
	
	return total
