extends Control

class_name DialogContainer

@export var shopUI:Control
@export var confirmDialog:Control


func _ready():
	CommandDispatcher.SHOW_SHOP_UI.connect(onShowShopUI)
	CommandDispatcher.SHOW_CONFIRMATION_DIALOG.connect(onConfirmDialogRequest)
	CommandDispatcher.CLOSE_DIALOG.connect(onCloseRequest)


func onShowShopUI(shopName, inventory):
	shopUI.shopNameLabel.text = shopName
	shopUI.shopInventoryItems = inventory
	shopUI.playerGoldValue.text = str(GameManager.player.gold)
	shopUI.show()
	show()


func onCloseRequest(caller):
	caller.hide()
	hide()
	CommandDispatcher.WAIT_FOR_COMMAND.emit()


func onConfirmDialogRequest(text, callback):
	confirmDialog.confirmTextLabel.text = text
	confirmDialog.yesCallback = callback
	confirmDialog.show()
