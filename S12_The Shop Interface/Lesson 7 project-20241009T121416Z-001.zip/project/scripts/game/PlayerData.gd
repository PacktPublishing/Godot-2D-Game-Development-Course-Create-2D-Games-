
class_name PlayerData

var playerName:String
var gold:int
var inventory:Array[Item] = []

func _init():
	playerName = "New Player"
	gold = 100
	
	inventory.clear()


func giveItem(item:Item):
	inventory.append(item)


func takeItem(item:Item):
	inventory.erase(item)
