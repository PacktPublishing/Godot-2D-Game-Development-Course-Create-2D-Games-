extends Control


func _on_new_game_button_pressed():
	Loader.loadScene(self, "res://scenes/game_screen.tscn")
