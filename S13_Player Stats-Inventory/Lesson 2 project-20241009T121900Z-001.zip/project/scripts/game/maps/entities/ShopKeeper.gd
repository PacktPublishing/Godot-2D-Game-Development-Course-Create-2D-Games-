extends Mob2D

class_name ShopKeeper

enum Responses { Yes, No }

@export var shopName:String
@export var inventory:Array[ItemDefinition]
@export var buybackFilter:ItemDefinition.ItemTypes

func interact():
	CommandDispatcher.DISPLAY_PROMPT.emit("**%s**: Would you like to see my wares?\n\n" % shopName, Responses.keys(), onResponse)


func onResponse(selected):
	match(selected):
		Responses.Yes:
			CommandDispatcher.SHOW_SHOP_UI.emit(shopName, inventory, buybackFilter)
		Responses.No:
			CommandDispatcher.DISPLAY_MESSAGE.emit("Come back later, then.")
			CommandDispatcher.WAIT_FOR_COMMAND.emit()
