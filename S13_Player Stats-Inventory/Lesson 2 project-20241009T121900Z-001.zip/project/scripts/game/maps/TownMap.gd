extends Map2D

class_name TownMap
