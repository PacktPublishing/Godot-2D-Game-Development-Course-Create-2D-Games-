extends Node

var startMap:String = "res://scenes/game/maps/world_map.tscn"

var currentMap:String

var player:PlayerData

func startNewGame():
	currentMap = startMap
	player = PlayerData.new()
