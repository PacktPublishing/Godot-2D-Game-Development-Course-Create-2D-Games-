
class_name PlayerData

var playerName:String
var gold:int
var inventory:Array[Item] = []

var strength:int
var agility:int
var endurance:int
var luck:int

var health:int
var mana:int

var currentHealth:int
var currentMana:int


func _init():
	playerName = "New Player"
	gold = 100
	
	inventory.clear()


func giveItem(item:Item):
	inventory.append(item)


func takeItem(item:Item):
	inventory.erase(item)
