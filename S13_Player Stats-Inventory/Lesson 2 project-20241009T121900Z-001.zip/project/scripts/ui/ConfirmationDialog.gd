extends Control

class_name ConfirmYesNoDialog

@export var confirmTextLabel:Label

var yesCallback:Callable

func _on_yes_button_pressed():
	hide()
	yesCallback.call()


func _on_no_button_pressed():
	hide()
