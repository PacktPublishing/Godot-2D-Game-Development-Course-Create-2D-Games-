
class_name PlayerData

enum EquipSlots { Weapon, Armor, Item }

var playerName:String
var gold:int
var inventory:Array[Item] = []

var equippedItems:Array[Item] = []

var strength:int
var agility:int
var endurance:int
var luck:int

var health:int
var mana:int

var currentHealth:int
var currentMana:int


func _init():
	playerName = "New Player"
	gold = 100
	
	inventory.clear()
	
	if (equippedItems.size() != EquipSlots.keys().size()):
		equippedItems.resize(EquipSlots.keys().size())


func giveItem(item:Item):
	inventory.append(item)


func takeItem(item:Item):
	inventory.erase(item)

func isEquipped(item:Item) -> bool:
	return equippedItems[item.itemType] == item


func equipItem(item:Item):
	equippedItems[item.itemType] = item


func unequipItem(item:Item):
	equippedItems[item.itemType] = null
