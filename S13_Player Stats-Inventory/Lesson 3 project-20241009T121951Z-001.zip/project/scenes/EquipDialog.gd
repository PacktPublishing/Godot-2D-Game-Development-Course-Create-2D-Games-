extends PanelContainer

class_name EquipDialog

@export var header:Label
@export var itemsContainer:VBoxContainer

var itemEntryPrefab = preload("res://scenes/ui/EquipItemEntry.tscn")

var filter

func _on_ok_button_pressed():
	CommandDispatcher.CLOSE_DIALOG.emit(self)


func updateDisplay():
	var item
	
	header.text = "Equip %s" % [ItemDefinition.ItemTypes.keys()[filter]]
	
	for itemEntry in itemsContainer.get_children():
		item.queue_free()

	for itemEntry in GameManager.player.inventory:
		if (itemEntry.itemType != filter):
			continue
			
		item = itemEntryPrefab.instantiate() as Button
		
		item.text = itemEntry.itemName
		
		itemsContainer.add_child(item)
