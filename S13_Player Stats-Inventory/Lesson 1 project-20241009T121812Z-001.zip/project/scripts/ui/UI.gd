extends Control

class_name UI

func _ready():
	pass


func _on_pass_button_pressed():
	CommandDispatcher.PROCESS_COMMAND.emit(PassCommand.new())


func _on_speak_button_pressed():
	CommandDispatcher.PROCESS_COMMAND.emit(SpeakCommand.new())



func _on_inventory_button_pressed():
	CommandDispatcher.PAUSE_PROCESSOR.emit()
	CommandDispatcher.SHOW_CHARACTER_INFO_DIALOG.emit()
