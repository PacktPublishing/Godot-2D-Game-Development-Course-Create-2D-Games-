extends Control

class_name DialogContainer

@export var shopUI:Control
@export var confirmDialog:Control
@export var characterInfoDialog:Control

func _ready():
	CommandDispatcher.SHOW_SHOP_UI.connect(onShowShopUI)
	CommandDispatcher.SHOW_CONFIRMATION_DIALOG.connect(onConfirmDialogRequest)
	CommandDispatcher.CLOSE_DIALOG.connect(onCloseRequest)
	CommandDispatcher.SHOW_CHARACTER_INFO_DIALOG.connect(onCharacterInfoDialogRequest)


func onShowShopUI(shopName, inventory, filter):
	shopUI.shopNameLabel.text = shopName
	shopUI.shopInventoryItems = inventory
	shopUI.mode = ShopUI.Modes.Buy
	shopUI.filter = filter
	shopUI.playerGoldAmount.text = str(GameManager.player.gold)
	shopUI.show()
	show()


func onCloseRequest(caller):
	caller.hide()
	hide()
	CommandDispatcher.WAIT_FOR_COMMAND.emit()


func onConfirmDialogRequest(text, callback):
	confirmDialog.confirmTextLabel.text = text
	confirmDialog.yesCallback = callback
	confirmDialog.show()


func onCharacterInfoDialogRequest():
	characterInfoDialog.updateDisplay()
	characterInfoDialog.show()
	show()
