extends Mob

class_name Player3D

func _ready():
	GameManager.player.DAMAGE_CHANGED.connect(onDamageChanged)
	GameManager.player.DEFENSE_CHANGED.connect(onDefenseChanged)
	health = GameManager.player.health

func canSee(object, map:TileMap) -> bool:
	var directionVector = Mob3D.DIRECTION_VECTORS[facing]
	var originTile = Vector2(map.local_to_map(position))
	var tile
	
	if (!is_instance_valid(object)):
		return false
	
	for tileIndex in range(1, DungeonView3D.MAX_VIEW_DISTANCE + 1):
		tile = Vector2i(originTile + directionVector * tileIndex)

		if (map.get_cell_atlas_coords(0, tile).x == DungeonView3D.TileIndex.SOLID):
			return false
		else:
			if (map.local_to_map(object.position) == tile):
				return true
				
	return false


func onDie():
	CommandDispatcher.PLAYER_DIED.emit()
