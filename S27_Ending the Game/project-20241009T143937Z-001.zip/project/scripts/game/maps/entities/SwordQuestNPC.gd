extends Mob2D

enum QuestResponses { Yes, No }

var questItem = preload("res://data/items/sword_of_questor.tres")

func interact():
	if (GameManager.player.isFlagSet(GameManager.Flags.ACCEPTED_SWORD_QUEST)):
		if (!GameManager.player.isFlagSet(GameManager.Flags.COMPLETED_SWORD_QUEST)):
			if (GameManager.player.hasItem(questItem)):
				CommandDispatcher.DISPLAY_MESSAGE.emit("The Legendary Sword of Questor!  You did it!  Thank you so much.")
				GameManager.player.takeItemByName(questItem.itemName)
				GameManager.player.gold += 1000
				GameManager.player.setFlag(GameManager.Flags.COMPLETED_SWORD_QUEST)
			else:
				CommandDispatcher.DISPLAY_MESSAGE.emit("Hope you're not finding the quest too difficult...")
		else:
			CommandDispatcher.DISPLAY_MESSAGE.emit("Thanks again for returning the sword!")
	else:
		CommandDispatcher.DISPLAY_PROMPT.emit("Do you want to go on a quest for me?", ["Yes", "No"], onQuestOfferResponse)


func onQuestOfferResponse(selection):
	match (selection):
		QuestResponses.Yes:
			CommandDispatcher.DISPLAY_MESSAGE.emit("Great!  The Legendary Sword of Questor is a powerful artifact that can be found in the Desert Dungeon.  Bring it back to me here and I will reward you!")
			GameManager.player.setFlag(GameManager.Flags.ACCEPTED_SWORD_QUEST)
		QuestResponses.No:
			CommandDispatcher.DISPLAY_MESSAGE.emit("Come back when you're feeling up to the task.")

	CommandDispatcher.WAIT_FOR_COMMAND.emit()
