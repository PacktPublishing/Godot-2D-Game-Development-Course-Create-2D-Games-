extends Control

@export var textScroll:Control

var caller

func _on_skip_button_pressed():
	var tween = create_tween()
	
	tween.tween_property(textScroll, "modulate:a", 0, 1.0)
	
	await tween.finished
	
	onFinish()


func _on_animation_player_animation_finished(anim_name):
	onFinish()


func onFinish():
	queue_free()
	
	Loader.loadScene(caller, "res://scenes/ui/title_screen.tscn")
