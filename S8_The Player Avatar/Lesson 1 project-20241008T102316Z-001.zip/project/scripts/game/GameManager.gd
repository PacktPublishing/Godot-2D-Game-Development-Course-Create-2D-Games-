extends Node

var defaultMapPath:String = "res://scenes/game/maps/world_map.tscn"

var currentMapPath

func startNewGame():
	currentMapPath = defaultMapPath
