extends TileMap

class_name Map

enum Direction { North, East, South, West }
