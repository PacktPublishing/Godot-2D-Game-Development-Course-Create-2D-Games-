extends Command

class_name PassCommand

func _init():
	commandLabel = "Pass"


func execute():
	print("Player passed.")
	COMMAND_PROCESSED.emit(commandLabel)
