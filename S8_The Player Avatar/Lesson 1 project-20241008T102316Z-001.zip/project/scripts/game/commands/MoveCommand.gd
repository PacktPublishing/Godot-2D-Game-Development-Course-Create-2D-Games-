extends Command

class_name MoveCommand

var direction

func _init(dir):
	commandLabel = "Move"
	direction = dir


func execute():
	CommandDispatcher.PLAYER_MOVE.emit(direction)
	emit_signal("COMMAND_PROCESSED", getCommandText())


func getDirectionString() -> String:
	return Map.Direction.keys()[direction]


func getCommandText():
	return "%s %s" % [commandLabel, getDirectionString()]
