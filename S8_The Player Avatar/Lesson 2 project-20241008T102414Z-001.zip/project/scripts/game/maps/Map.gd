extends TileMap

class_name Map

enum Direction { North, East, South, West }

@export var defaultPlayerStartPosition:Vector2i

var player

func spawnPlayerAtPosition(position, facing):
	var spawnposition
	
	if (position == null):
		spawnposition = defaultPlayerStartPosition
	else:
		spawnposition = position

	player.position = Vector2(spawnposition.x * 16, spawnposition.y * 16)
