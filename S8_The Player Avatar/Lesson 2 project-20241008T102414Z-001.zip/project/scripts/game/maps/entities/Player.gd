extends Mob
