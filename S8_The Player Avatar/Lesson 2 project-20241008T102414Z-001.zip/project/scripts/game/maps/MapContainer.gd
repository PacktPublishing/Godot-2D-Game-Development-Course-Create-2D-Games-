extends Node

@export var entities:Node

var map:Map

func _ready():
	CommandDispatcher.LOAD_MAP.connect(loadMap)


func loadMap(currentMapPath, newMapPath, spawnpoint, facing):
	var newMap:Map = load(newMapPath).instantiate()
	
	CommandDispatcher.PAUSE_PROCESSOR.emit()
	
	if (currentMapPath != null):
		currentMapPath.queue_free()
	
	add_child(newMap)

	entities.add_child(newMap.spawnPlayerAtPosition(spawnpoint, facing))

	CommandDispatcher.WAIT_FOR_COMMAND.emit()
