extends Node

class_name GameScreen

@export var map:Node

func _ready():
	CommandDispatcher.LOAD_MAP.emit(null, GameManager.defaultMapPath, null, Map.Direction.North)


func _on_pass_button_pressed():
	CommandDispatcher.PROCESS_COMMAND.emit(PassCommand.new())
