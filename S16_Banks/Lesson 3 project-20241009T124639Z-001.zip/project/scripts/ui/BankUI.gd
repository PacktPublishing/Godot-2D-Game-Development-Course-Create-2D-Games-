extends PanelContainer

class_name BankUI

@export var bankName:Label
@export var playerGold:Label
@export var bankBalance:Label
@export var transactionAmount:SpinBox

func _ready():
	GameManager.player.GOLD_AMOUNT_CHANGED.connect(onPlayerGoldAmountChanged)
	GameManager.player.BANK_BALANCE_CHANGED.connect(onBankBalanceAmountChanged)

func _on_deposit_button_pressed():
	var amount = min(transactionAmount.value, GameManager.player.gold)

	GameManager.player.gold -= amount
	GameManager.player.bankBalance += amount

func _on_withdraw_button_pressed():
	var amount = min(transactionAmount.value, GameManager.player.bankBalance)

	GameManager.player.gold += amount
	GameManager.player.bankBalance -= amount


func _on_leave_button_pressed():
	CommandDispatcher.SHOW_CONFIRMATION_DIALOG.emit("Leave %s?" % bankName.text, onLeave)


func onPlayerGoldAmountChanged(amount):
	playerGold.text = str(amount)


func onBankBalanceAmountChanged(amount):
	bankBalance.text = str(amount)


func onLeave():
	CommandDispatcher.DISPLAY_MESSAGE.emit("Thank you, come again!")
	CommandDispatcher.CLOSE_DIALOG.emit(self, true)
