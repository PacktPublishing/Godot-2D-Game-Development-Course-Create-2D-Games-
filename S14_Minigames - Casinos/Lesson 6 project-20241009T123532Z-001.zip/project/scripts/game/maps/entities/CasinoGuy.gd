extends Mob2D

class_name CasinoGuy

@export var casinoName:String
@export_file var casinoScene:String
