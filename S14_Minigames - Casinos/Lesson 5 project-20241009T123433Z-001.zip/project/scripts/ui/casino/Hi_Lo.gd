extends Control

class_name CasinoGameHiLo

@export_group("Controls")
@export var playfield:HBoxContainer
@export var controlPanel:CasinoControlPanel
@export var confirmDialog:ConfirmYesNoDialog
@export var playerGoldValueLabel:Label
@export var payoutGoldValueLabel:Label
@export var howToPlayDialog:Control

@export_group("Betting")
@export var payoutMultiplier := 1.5

var rng:RandomNumberGenerator = RandomNumberGenerator.new()
var playingCardPrefab = preload("res://scenes/game/casino/playing_card.tscn")

var payout:int:
	set(value):
		payout = value
		payoutGoldValueLabel.text = str(payout)


func _ready():
	playerGoldValueLabel.text = str(GameManager.player.gold)
	promptPlayerForInstructions()


func promptPlayerForInstructions():
	confirmDialog.noButton.pressed.connect(startGame)
	confirmDialog.confirmTextLabel.text = "Do you want to see the instructions?"
	confirmDialog.yesCallback = showInstructions
	confirmDialog.show()


func startGame():
	controlPanel.setStatusText("Place initial bet:")
	controlPanel.showBettingControls()


func showInstructions():
	howToPlayDialog.show()


func _on_how_to_play_ok_button_pressed():
	howToPlayDialog.hide()
	startGame()


func _on_higher_button_pressed():
	pass # Replace with function body.


func _on_lower_button_pressed():
	pass # Replace with function body.


func _on_guess_again_button_pressed():
	pass # Replace with function body.


func _on_stop_guessing_button_pressed():
	pass # Replace with function body.


func _on_place_bet_button_pressed():
	payout = controlPanel.betEntry.value * payoutMultiplier
	GameManager.player.gold -= controlPanel.betEntry.value
	controlPanel.hideAllControls()
	controlPanel.setStatusText("")


func _on_leave_button_pressed():
	pass # Replace with function body.
