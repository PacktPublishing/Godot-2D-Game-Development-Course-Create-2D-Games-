extends PanelContainer

class_name CasinoControlPanel

@export var controls:Control
@export var higherButton:Button
@export var lowerButton:Button
@export var guessAgainButton:Button
@export var stopGuessingButton:Button
@export var placeBetButton:Button
@export var leaveButton:Button

@export var betEntry:SpinBox
@export var statusText:Label

@export var minimumBet:int = 10
@export var maximumBet:int = 100

var defaultMaximumBetValue

func _ready():
	GameManager.player.GOLD_AMOUNT_CHANGED.connect(onPlayerGoldAmountChanged)
	
	defaultMaximumBetValue = maximumBet
	
	betEntry.min_value = minimumBet
	betEntry.max_value = maximumBet
	
	setStatusText("")
	

func onPlayerGoldAmountChanged(value):
	if (value < maximumBet):
		maximumBet = value
	else:
		maximumBet = defaultMaximumBetValue

	betEntry.max_value = maximumBet

func setStatusText(text):
	statusText.text = text


func hideAllControls():
	for control in controls.get_children():
		control.hide()


func showBettingControls():
	betEntry.show()
	placeBetButton.show()
	leaveButton.show()
