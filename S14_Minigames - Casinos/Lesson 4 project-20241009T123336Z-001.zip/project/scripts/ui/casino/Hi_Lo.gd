extends Control

class_name CasinoGameHiLo

@export_group("Controls")
@export var playfield:HBoxContainer
@export var controlPanel:CasinoControlPanel
@export var confirmDialog:ConfirmYesNoDialog
@export var playerGoldValueLabel:Label
@export var payoutGoldValueLabel:Label

@export_group("")

