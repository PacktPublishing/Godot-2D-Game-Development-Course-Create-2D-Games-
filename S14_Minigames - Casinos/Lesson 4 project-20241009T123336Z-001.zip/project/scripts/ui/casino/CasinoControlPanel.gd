extends PanelContainer

class_name CasinoControlPanel

@export var higherButton:Button
@export var lowerButton:Button
@export var guessAgainButton:Button
@export var stopGuessingButton:Button
@export var placeBetButton:Button
@export var leaveButton:Button

@export var betEntry:SpinBox
@export var statusText:Label

@export var minimumBet:int = 10
@export var maximumBet:int = 100

func _ready():
	GameManager.player.GOLD_AMOUNT_CHANGED.connect(onPlayerGoldAmountChanged)


func onPlayerGoldAmountChanged(value):
	pass
