extends Control

class_name PlayingCard

@export var cardFace:AnimatedSprite2D

enum Suits { Hearts, Diamonds, Spades, Clubs }
enum Faces { Two, Three, Four, Five, Six, Seven, Eight, Nine, Ten, Jack, Queen, King, MISC }

const CARD_BACK:int = 27

var cardFrame:int:
	get:
		return (suit * Faces.keys().size()) + face

var suit:Suits
var face:Faces

func _init(s, f, faceUp):
	suit = s
	face = f
	
	if (faceUp):
		cardFace.frame = cardFrame
	else:
		cardFace.frame = CARD_BACK


func flip():
	if (cardFace.frame == CARD_BACK):
		cardFace.frame = cardFrame
	else:
		cardFace.frame = CARD_BACK
