extends Resource

class_name EncounterTable

@export var commonEncounters:Array[PackedScene]
@export var uncommonEncounters:Array[PackedScene]
@export var rareEncounters:Array[PackedScene]

func getEncounter() -> WorldMapEncounterMob:
	var roll = randi_range(0, 100)
	
	var table = commonEncounters
	
	if (roll < 33):
		table = uncommonEncounters
	
	if (roll < 10):
		table = rareEncounters

	return table[randi_range(0, table.size() - 1)].instantiate()

