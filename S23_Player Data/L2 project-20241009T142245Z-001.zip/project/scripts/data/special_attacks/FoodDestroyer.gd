extends SpecialAttack

class_name FoodDestroyerAttack

func execute(attacker, target):
	super.execute(attacker, target)
	GameManager.player.food = max(0, GameManager.player.food - amount)


func getCombatString(attacker, target) -> String:
	return combatString % [attacker.mobName, amount]
