extends Resource

class_name SpecialAttack

@export var combatString := "%s does a special attack."
@export var amount := 0

func execute(attacker, target):
	CommandDispatcher.DISPLAY_MESSAGE.emit(getCombatString(attacker, target))


func getCombatString(attacker, target) -> String:
	return combatString % attacker.mobName
