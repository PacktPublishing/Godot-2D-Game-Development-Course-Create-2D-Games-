
class_name PlayerData

signal GOLD_AMOUNT_CHANGED(value)
signal BANK_BALANCE_CHANGED(value)
signal HP_AMOUNT_CHANGED(value)
signal FOOD_AMOUNT_CHANGED(value)

enum EquipSlots { Weapon, Armor, Item }

var playerName:String

var timePassed:float:
	set(value):
		timePassed = value
		
		if (timePassed >= 1):
			timePassed -= 1
			bankBalance += bankBalance * bankInterestRate

var gold:int:
	set(value):
		gold = value
		GOLD_AMOUNT_CHANGED.emit(gold)


var bankBalance:float:
	set(value):
		bankBalance = value
		BANK_BALANCE_CHANGED.emit(bankBalance)

var food:float:
	set(value):
		food = value
		FOOD_AMOUNT_CHANGED.emit(food)

var inventory:Array[Item] = []

var equippedItems:Array[Item] = []

var strength:int
var agility:int
var endurance:int
var luck:int

var maxHealth:int
var health:int:
	set(value):
		health = clamp(value, 0, maxHealth)
		HP_AMOUNT_CHANGED.emit(health)
		
var mana:int

var currentHealth:int
var currentMana:int

var bankInterestRate := 0.05

var xp

var flags:Array[bool] = []

func _init():
	playerName = "New Player"
	gold = 100
	maxHealth = 100
	food = 1000
	health = maxHealth
	xp = 0
	
	inventory.clear()
	
	if (equippedItems.size() != EquipSlots.keys().size()):
		equippedItems.resize(EquipSlots.keys().size())

	if (flags.size() != GameManager.Flags.keys().size()):
		flags.resize(GameManager.Flags.keys().size())
		
	setFlag(GameManager.Flags.COMPLETED_HEALING_HERB_QUEST)


func giveItem(item):
	inventory.append(item)


func takeItem(item):
	if (item.itemType <= ItemDefinition.ItemTypes.Item):
		if (hasItemEquipped(item)):
			unequipItem(item)
		
	inventory.erase(item)


func isEquipped(item:Item) -> bool:
	return equippedItems[item.itemType] == item


func equipItem(item:Item):
	equippedItems[item.itemType] = item


func unequipItem(item:Item):
	equippedItems[item.itemType] = null


func hasItemEquipped(item:Item):
	return equippedItems[item.itemType] == item


func getMail(postalCode) -> Array[Mail]:
	var mail:Array[Mail] = []
	
	for item in inventory:
		if (item is Mail):
			if (item.destination == postalCode):
				mail.append(item)
	
	return mail


func setFlag(flag):
	flags[flag] = true


func clearFlag(flag):
	flags[flag] = false
	

func isFlagSet(flag) -> bool:
	return flags[flag]


func useItem(item:Item):
	item.use()
	
	if (item.itemType == ItemDefinition.ItemTypes.Healing):
		takeItem(item)
