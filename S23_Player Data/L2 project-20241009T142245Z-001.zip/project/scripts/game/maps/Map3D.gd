extends Map

class_name Map3D

@export var dungeonView:DungeonView3D
@export var entities:Node2D
@export var spawnpoints:Node2D
@export var objects:Node2D

@export var encounterTable:EncounterTable

func _ready():
	super._ready()
	spawnMonsters()
	CommandDispatcher.PLAYER_TURN.connect(onPlayerTurn)
	CommandDispatcher.PROCESS_REACTIONS.connect(onReaction)


func spawnPlayerAtPosition(newPosition, facing):
	player = load("res://scenes/game/maps/entities/player_3d.tscn").instantiate()
	
	super.spawnPlayerAtPosition(newPosition, facing)
	
	player.facing = facing
	
	updateView()


func onLoaded():
	CommandDispatcher.ENABLE_DUNGEON_COMMANDS.emit()


func _unhandled_key_input(_event):
	if (Input.is_action_pressed("ui_right")):
		CommandDispatcher.PROCESS_COMMAND.emit(TurnCommand.new(TurnCommand.Directions.Right))
	
	if (Input.is_action_pressed("ui_left")):
		CommandDispatcher.PROCESS_COMMAND.emit(TurnCommand.new(TurnCommand.Directions.Left))
	
	if (Input.is_action_pressed("ui_up")):
		CommandDispatcher.PROCESS_COMMAND.emit(DungeonMoveCommand.new(player.facing, DungeonMoveCommand.SecondaryDirections.Forward))
		
	if (Input.is_action_pressed("ui_down")):
		var command = DungeonMoveCommand.new(Map.Direction.North, DungeonMoveCommand.SecondaryDirections.Backward)

		if (player.facing < Map.Direction.South):
			command.direction = player.facing + 2
			CommandDispatcher.PROCESS_COMMAND.emit(command)
		else:
			command.direction = player.facing - 2
			CommandDispatcher.PROCESS_COMMAND.emit(command)


func onPlayerTurn(direction):
	match(direction):
		TurnCommand.Directions.Left:
			player.facing -= 1
		TurnCommand.Directions.Right:
			player.facing += 1
	
	if (player.facing < Direction.North):
		player.facing = Direction.West
	
	if (player.facing > Direction.West):
		player.facing = Direction.North


func onPlayerMove(direction):
	var blockingEntity = getEntityAtPosition(calculateNewPosition(direction))
	
	if (blockingEntity == null):
		super.onPlayerMove(direction)
	else:
		player.attack(blockingEntity)


func getEntityAtPosition(pos):
	for entity in entities.get_children():
		if (entity.position == pos):
			return entity
	
	return null


func getObjectAtPosition(pos):
	for object in objects.get_children():
		if (object.position == pos):
			return object
	
	return null


func playerCanMoveTo(pos:Vector2) -> bool:
	var cellPos = local_to_map(pos)
	
	if (get_cell_atlas_coords(0, cellPos).x == DungeonView3D.TileIndex.EMPTY):
		return true
	else:
		CommandDispatcher.DISPLAY_MESSAGE.emit("Your path is blocked.")
		return false


func spawnMonsters():
	for spawnpoint in spawnpoints.get_children():
		spawnMonster(spawnpoint)


func spawnMonster(spawnpoint):
	var monster = encounterTable.getEncounter()
	
	monster.position = spawnpoint.position
	monster.map = self
	
	entities.add_child(monster)


func onReaction():
	for entity in entities.get_children():
		entity.onReaction()
		
	updateView()


func updateView():
	for entity in entities.get_children():
		if (entity != player):
			if (player.canSee(entity, self)):
				dungeonView.objectContainer.addMob(entity)
			else:
				dungeonView.objectContainer.removeMob(entity)

	for object in objects.get_children():
		if (player.canSee(object, self)):
			dungeonView.objectContainer.addObject(object)
		else:
			dungeonView.objectContainer.removeObject(object)
	
	dungeonView.updateView(self, player)
	dungeonView.objectContainer.updateRenderStack(self)


func onOpenContainerRequest():
	var pos = player.position + Mob3D.DIRECTION_VECTORS[player.facing] * Vector2(tile_set.tile_size)
	var container = getObjectAtPosition(pos)
	
	if (container != null):
		container.open()
		dungeonView.objectContainer.fadeRenderable(self, "Object", container)
	else:
		CommandDispatcher.DISPLAY_MESSAGE.emit("There is nothing to open here.")
