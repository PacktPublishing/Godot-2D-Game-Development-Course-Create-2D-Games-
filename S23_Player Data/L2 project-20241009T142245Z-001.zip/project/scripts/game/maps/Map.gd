extends TileMap

class_name Map

enum Direction { North, East, South, West }

@export var defaultPlayerStartPosition:Vector2i
@export var stepIncrement:float = 1.0
@export var timeIncrement:float

var player
var rng:RandomNumberGenerator = RandomNumberGenerator.new()

func _ready():
	CommandDispatcher.PLAYER_MOVE.connect(onPlayerMove)
	CommandDispatcher.TOGGLE_TILEMAP_LAYER.connect(onToggleRequest)
	CommandDispatcher.PLAYER_SPEAK.connect(onSpeak)
	CommandDispatcher.REGISTER_PLAYER.connect(onRegisterPlayerRequest)
	CommandDispatcher.OPEN_CONTAINER.connect(onOpenContainerRequest)
	

func spawnPlayerAtPosition(newPosition, _facing):
	var spawnposition:Vector2i
	
	if (newPosition == null):
		spawnposition = defaultPlayerStartPosition
	else:
		spawnposition = newPosition
	
	player.position = Vector2(spawnposition.x * 16, spawnposition.y * 16)
	
	get_node("Entities").add_child(player)


func calculateNewPosition(direction) -> Vector2:
	var newPos = Vector2(player.position)
	var moveIncrement = tile_set.tile_size.x * stepIncrement
	
	match(direction):
		Direction.North:
			newPos.y -= moveIncrement
		Direction.South:
			newPos.y += moveIncrement
		Direction.West:
			newPos.x -= moveIncrement
		Direction.East:
			newPos.x += moveIncrement

	return newPos


func onPlayerMove(direction):
	var newPos = calculateNewPosition(direction)
	
	if (playerCanMoveTo(newPos)):
		GameManager.player.food -= getFoodConsumptionRate()
		player.position = newPos
		player.updateAnimation(direction)
	
	GameManager.player.timePassed += timeIncrement


func playerCanMoveTo(_newPosition) -> bool:
	return false


func onToggleRequest(layerName, visible):
	for layer in range(get_layers_count()):
		if (get_layer_name(layer) == layerName):
			set_layer_enabled(layer, visible)


func onSpeak():
	var interactables:Array = player.speechCollider.get_overlapping_areas()
	
	if (interactables.size() > 0):
		for interactable in interactables:
			interactable.get_parent().interact()
	else:
		CommandDispatcher.DISPLAY_MESSAGE.emit("There is no one to speak to.")


func getFoodConsumptionRate() -> float:
	return 0


func onRegisterPlayerRequest(mob:Mob):
	mob.player = player


func onLoaded():
	pass


func onOpenContainerRequest():
	pass
