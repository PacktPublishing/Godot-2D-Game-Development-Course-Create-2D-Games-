extends Mob2D

class_name Healer

@export var shopName:String
@export var inventory:Array[ItemDefinition]
@export var healingCost:int

enum Responses { Heal, Buy }
enum ResponsesYesNo { Yes, No }

func interact():
	if (GameManager.player.isFlagSet(GameManager.Flags.COMPLETED_HEALING_HERB_QUEST)):
		CommandDispatcher.DISPLAY_PROMPT.emit(
			"**%s**: Are you in need of healing, or do you wish to purchase some medicinal herbs?" % shopName,
			["Heal", "Buy herbs"],
			onResponse)
	else:
		CommandDispatcher.DISPLAY_MESSAGE.emit("Sorry, but you didn't complete the healing quest.")
		
		
func onResponse(selection):
	match(selection):
		
		Responses.Heal:
			var damage = GameManager.player.maxHealth - GameManager.player.health
			
			if (damage > 0):
				CommandDispatcher.DISPLAY_PROMPT.emit("It will cost %s to heal you fully." % (damage * healingCost), ["Yes", "No"], onHealingResponse)
			else:
				CommandDispatcher.DISPLAY_MESSAGE.emit("You look fine to me.")
				CommandDispatcher.WAIT_FOR_COMMAND.emit()

		Responses.Buy:
			CommandDispatcher.SHOW_SHOP_UI.emit(self, inventory, ItemDefinition.ItemTypes.Healing)
			

func onHealingResponse(selection):
	match(selection):
	
		ResponsesYesNo.Yes:
			var cost = (GameManager.player.maxHealth - GameManager.player.health) * healingCost
			
			if (cost <= GameManager.player.gold):
				GameManager.player.health = GameManager.player.maxHealth
				GameManager.player.gold -= cost
				
				CommandDispatcher.DISPLAY_MESSAGE.emit("You are healed!")
			else:
				CommandDispatcher.DISPLAY_MESSAGE.emit("Sorry, but you can't afford my services.")

		ResponsesYesNo.No:
			CommandDispatcher.DISPLAY_MESSAGE.emit("Be careful out there.")

	CommandDispatcher.WAIT_FOR_COMMAND.emit()


func onLeftShop(shopUi):
	pass
