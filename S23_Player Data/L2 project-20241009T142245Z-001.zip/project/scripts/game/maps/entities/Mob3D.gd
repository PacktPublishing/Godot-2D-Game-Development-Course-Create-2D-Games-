extends Mob

class_name Mob3D

const DIRECTION_VECTORS = [Vector2.UP, Vector2.RIGHT, Vector2.DOWN, Vector2.LEFT]

# The sprite's frame is equal to the number of squares away from the player
# that the mob is, plus one.  Eg. frame 2 = 3 squares away.
@export var sprite:Sprite2D
@export var maxVisibilityDistance := 4

@export_group("Special Attacks")
@export var percentChanceOfSpecial := 0
@export var specialAttack:SpecialAttack

@export_group("Treasure")
@export var minimumGold := 10
@export var maximumGold := 100

var map:Map3D

func _ready():
	hostile = true


func onReaction():
	super.onReaction()
	
	var intendedDirection = determineDirection()
	var intendedPosition = position + intendedDirection * Vector2(map.tile_set.tile_size)
	var blockingEntity = map.getEntityAtPosition(intendedPosition)

	if (blockingEntity == null):
		position = intendedPosition
	else:
		if (blockingEntity == map.player):
			attack(map.player)


func playerIsInRange() -> bool:
	return map.player.position.distance_to(position) <= maxVisibilityDistance * map.tile_set.tile_size.x
	
	
func determineDirection() -> Vector2:
	if (playerIsInRange() and canSeePlayer()):
		return getDirectionVectorToPlayer()
	else:
		return getRandomDirection()


func getRandomDirection() -> Vector2:
	var directions = DIRECTION_VECTORS.duplicate()
	var intendedDirection = randi_range(0, directions.size() - 1)

	while map.get_cell_atlas_coords(0, map.local_to_map(position + directions[intendedDirection] * Vector2(map.tile_set.tile_size))).x == DungeonView3D.TileIndex.SOLID:
		directions.remove_at(intendedDirection)
		intendedDirection = randi_range(0, directions.size() - 1)
	
	return directions[intendedDirection]


func getDirectionVectorToPlayer() -> Vector2:
	var direction = map.player.position - position
		
	if (direction.x != 0):
		direction.x /= abs(direction.x)
	
	if (direction.y != 0):
		direction.y /= abs(direction.y)

	return direction


func canBeSeenByPlayer() -> bool:
	var directionToPlayer = getDirectionVectorToPlayer()
	var playerIsFacingMob = directionToPlayer == DIRECTION_VECTORS[map.player.facing] * -1
	var lineOfSightExists = false
	var mobTile = Vector2(map.local_to_map(position))
	var tile

	if (playerIsFacingMob):
		lineOfSightExists = canSeePlayer()

	return playerIsFacingMob and lineOfSightExists and playerIsInRange()


func canSeePlayer() -> bool:
	var directionToPlayer = getDirectionVectorToPlayer()
	var lineOfSightExists = true
	var mobTile = Vector2(map.local_to_map(position))
	var tile
		
	for tileIndex in range(1, maxVisibilityDistance + 1):
		tile = mobTile + directionToPlayer * tileIndex
		
		if (tile * Vector2(map.tile_set.tile_size) == map.player.position):
			break
			
		if (map.get_cell_atlas_coords(0, mobTile + directionToPlayer * tileIndex).x == DungeonView3D.TileIndex.SOLID):
			lineOfSightExists = false
			break

	return lineOfSightExists and playerIsInRange()


func attack(target):
	if (randi_range(0, 100) < percentChanceOfSpecial):
		specialAttack.execute(self, target)
	else:
		super.attack(target)


func onTakeDamage(amount):
	super.onTakeDamage(amount)
	CommandDispatcher.DUNGEONVIEW_MOB_FLASH.emit()
