extends Node2D

class_name Chest

@export var sprite:Sprite2D

func open():
	var amount = randi_range(10, 100)

	GameManager.player.gold += amount
	CommandDispatcher.DISPLAY_MESSAGE.emit("You find %s gold." % amount)
	
	queue_free()
