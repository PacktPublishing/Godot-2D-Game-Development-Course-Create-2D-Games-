extends Map

class_name Map2D

enum TerrainDataTypes { TerrainType, FoodConsumption, EncounterChance }
	

func getTerrainDataForTile(layer, data, x, y):
	var tile:TileData = get_cell_tile_data(layer, Vector2i(x, y))

	if (tile != null):
		return tile.get_custom_data(TerrainDataTypes.keys()[data])
	else:
		return null


func spawnPlayerAtPosition(newPosition, facing):
	player = load("res://scenes/game/maps/entities/player.tscn").instantiate()
	
	super.spawnPlayerAtPosition(newPosition, facing)

	player.updateFacing(facing)


func playerCanMoveTo(newPosition:Vector2) -> bool:
	return !player.wouldCollideAt(newPosition)


func getFoodConsumptionRate() -> float:
	var tile = local_to_map(player.position)
	
	return getTerrainDataForTile(0, TerrainDataTypes.FoodConsumption, tile.x, tile.y)


func onLoaded():
	CommandDispatcher.ENABLE_WORLD_COMMANDS.emit()


func _unhandled_key_input(_event):
	var direction

	if (Input.is_action_pressed("ui_right")):
		direction = Map.Direction.East
	
	if (Input.is_action_pressed("ui_left")):
		direction = Map.Direction.West
	
	if (Input.is_action_pressed("ui_up")):
		direction = Map.Direction.North
		
	if (Input.is_action_pressed("ui_down")):
		direction = Map.Direction.South
	
	if (direction != null):
		CommandDispatcher.PROCESS_COMMAND.emit(MoveCommand.new(direction))
