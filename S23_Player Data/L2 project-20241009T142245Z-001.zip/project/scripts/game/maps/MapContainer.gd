extends Node

var map:Map
var loading:bool
var newSpawnpoint
var newFacing

func _ready():
	CommandDispatcher.LOAD_MAP.connect(loadMap)


func loadMap(newMapPath, spawnpoint, facing):
	
	CommandDispatcher.PAUSE_PROCESSOR.emit()
	
	if (map != null):
		map.queue_free()
	
	GameManager.currentMap = newMapPath
	
	loading = true
	
	ResourceLoader.load_threaded_request(GameManager.currentMap)
	
	newSpawnpoint = spawnpoint
	newFacing = facing


func _process(delta):
	if (loading):
		if (ResourceLoader.load_threaded_get_status(GameManager.currentMap) == ResourceLoader.THREAD_LOAD_LOADED):
			loading = false
			
			map = ResourceLoader.load_threaded_get(GameManager.currentMap).instantiate()
			
			call_deferred("add_child", map)
			
			map.spawnPlayerAtPosition(newSpawnpoint, newFacing)
			
			map.onLoaded()
			
			CommandDispatcher.LOAD_COMPLETE.emit()
			CommandDispatcher.WAIT_FOR_COMMAND.emit()
