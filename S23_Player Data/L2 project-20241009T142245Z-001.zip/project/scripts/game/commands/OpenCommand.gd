extends Command

class_name OpenCommand

func _init():
	commandLabel = "Open"


func execute():
	CommandDispatcher.OPEN_CONTAINER.emit()
	COMMAND_PROCESSED.emit(getCommandText())
