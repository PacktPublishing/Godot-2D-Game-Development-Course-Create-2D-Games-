extends Command

class_name TurnCommand

enum Directions { Left, Right }

var direction

func _init(dir):
	commandLabel = "Turn"
	direction = dir


func execute():
	CommandDispatcher.PLAYER_TURN.emit(direction)
	COMMAND_PROCESSED.emit(getCommandText())


func getDirectionString() -> String:
	return Directions.keys()[direction]


func getCommandText():
	return "%s %s" % [commandLabel, getDirectionString()]
