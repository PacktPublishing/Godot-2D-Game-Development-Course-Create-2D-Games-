extends Command

class_name UseCommand

func _init(dir):
	commandLabel = "Use"


func execute():
	
	COMMAND_PROCESSED.emit(getCommandText())
