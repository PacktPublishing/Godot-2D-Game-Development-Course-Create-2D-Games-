extends Node

# Command Processor Signals
signal PROCESS_COMMAND(command)
signal WAIT_FOR_COMMAND
signal PAUSE_PROCESSOR

# Game Signals
signal PLAYER_MOVE(direction)
signal PLAYER_SPEAK
signal PLAYER_TURN(direction)

# Message Console Signals
signal DISPLAY_MESSAGE(message)
signal DISPLAY_PROMPT(text, options, callback)
signal DISPLAY_COMMAND_PROMPT
signal DISPLAY_CLEAR

# Map signals
signal LOAD_MAP(newMapPath, spawnpoint, facing)
signal LOAD_COMPLETE

signal TOGGLE_TILEMAP_LAYER(layerName, visible)

# DialogContainer signals
signal SHOW_SHOP_UI(shopKeeper, inventory, filter)
signal SHOW_BANK_UI(bankName)
signal SHOW_FOOD_VENDOR_UI(vendorName, price)
signal SHOW_CONFIRMATION_DIALOG(text, okCallback)
signal CLOSE_DIALOG(dialog, resumeParser)
signal SHOW_CHARACTER_INFO_DIALOG
signal SHOW_EQUIP_DIALOG(filter)
signal SHOW_USE_DIALOG

signal PROCESS_REACTIONS
signal REGISTER_PLAYER(mob)

signal ENABLE_WORLD_COMMANDS
signal ENABLE_DUNGEON_COMMANDS

signal DUNGEONVIEW_MOB_FLASH

signal OPEN_CONTAINER
