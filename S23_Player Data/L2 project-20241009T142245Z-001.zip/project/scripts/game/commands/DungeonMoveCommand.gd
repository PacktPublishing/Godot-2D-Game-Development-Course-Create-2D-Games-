extends MoveCommand

class_name DungeonMoveCommand

enum SecondaryDirections { Forward, Backward }

var secondaryDirection

func _init(dir, secondaryDir):
	commandLabel = "Move"
	direction = dir
	secondaryDirection = secondaryDir


func getDirectionString() -> String:
	return SecondaryDirections.keys()[secondaryDirection]
