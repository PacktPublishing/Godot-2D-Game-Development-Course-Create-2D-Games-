extends PanelContainer

@export var itemsContainer:VBoxContainer

var itemEntryPrefab = preload("res://scenes/ui/EquipItemEntry.tscn")

var clickedItem

func _on_ok_button_pressed():
	CommandDispatcher.CLOSE_DIALOG.emit(self, true)


func updateDisplay():
	var item
	
	for itemEntry in itemsContainer.get_children():
		itemEntry.queue_free()

	for itemEntry in GameManager.player.inventory:
		if (itemEntry.itemType != ItemDefinition.ItemTypes.Item and itemEntry.itemType != ItemDefinition.ItemTypes.Healing):
			continue
			
		item = itemEntryPrefab.instantiate() as Button
		item.text = itemEntry.itemName
		
		item.pressed.connect(onInteract.bind(item, itemEntry))
		
		itemsContainer.add_child(item)


func onInteract(button, item):
	clickedItem = item
	CommandDispatcher.SHOW_CONFIRMATION_DIALOG.emit("Use %s?" % item.itemName, onConfirmUse)


func onConfirmUse():
	GameManager.player.useItem(clickedItem)
	CommandDispatcher.CLOSE_DIALOG.emit(self, true)
