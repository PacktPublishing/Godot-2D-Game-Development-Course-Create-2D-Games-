extends Mob

class_name Mob3D

# The sprite's frame is equal to the number of squares away from the player
# that the mob is, plus one.  Eg. frame 2 = 3 squares away.
@export var sprite:Sprite2D
@export var maxVisibilityDistance := 4
