extends TileMap

class_name Map

enum Direction { North, East, South, West }

@export var defaultPlayerStartPosition:Vector2i
@export var stepIncrement:float = 1.0

var player

func _ready():
	CommandDispatcher.PLAYER_MOVE.connect(onPlayerMove)


func spawnPlayerAtPosition(newPosition, _facing):
	var spawnposition:Vector2i
	
	if (newPosition == null):
		spawnposition = defaultPlayerStartPosition
	else:
		spawnposition = newPosition
	
	player.position = Vector2(spawnposition.x * 16, spawnposition.y * 16)


func onPlayerMove(direction):
	var newPos = Vector2(player.position)
	var moveIncrement = tile_set.tile_size.x * stepIncrement
	
	match(direction):
		Direction.North:
			newPos.y -= moveIncrement
		Direction.South:
			newPos.y += moveIncrement
		Direction.West:
			newPos.x -= moveIncrement
		Direction.East:
			newPos.x += moveIncrement
	
	if (playerCanMoveTo(newPos)):
		player.position = newPos
		player.updateAnimation(direction)


func playerCanMoveTo(_newPosition) -> bool:
	return false
