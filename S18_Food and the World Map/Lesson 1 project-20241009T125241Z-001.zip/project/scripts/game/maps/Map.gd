extends TileMap

class_name Map

enum Direction { North, East, South, West }

@export var defaultPlayerStartPosition:Vector2i
@export var stepIncrement:float = 1.0
@export var timeIncrement:float

var player

func _ready():
	CommandDispatcher.PLAYER_MOVE.connect(onPlayerMove)
	CommandDispatcher.TOGGLE_TILEMAP_LAYER.connect(onToggleRequest)
	CommandDispatcher.PLAYER_SPEAK.connect(onSpeak)


func spawnPlayerAtPosition(newPosition, _facing):
	var spawnposition:Vector2i
	
	if (newPosition == null):
		spawnposition = defaultPlayerStartPosition
	else:
		spawnposition = newPosition
	
	player.position = Vector2(spawnposition.x * 16, spawnposition.y * 16)


func onPlayerMove(direction):
	var newPos = Vector2(player.position)
	var moveIncrement = tile_set.tile_size.x * stepIncrement
	
	match(direction):
		Direction.North:
			newPos.y -= moveIncrement
		Direction.South:
			newPos.y += moveIncrement
		Direction.West:
			newPos.x -= moveIncrement
		Direction.East:
			newPos.x += moveIncrement
	
	if (playerCanMoveTo(newPos)):
		player.position = newPos
		player.updateAnimation(direction)
	
	GameManager.player.timePassed += timeIncrement


func playerCanMoveTo(_newPosition) -> bool:
	return false


func onToggleRequest(layerName, visible):
	for layer in range(get_layers_count()):
		if (get_layer_name(layer) == layerName):
			set_layer_enabled(layer, visible)


func onSpeak():
	var interactables:Array = player.speechCollider.get_overlapping_areas()
	
	if (interactables.size() > 0):
		for interactable in interactables:
			interactable.get_parent().interact()
	else:
		CommandDispatcher.DISPLAY_MESSAGE.emit("There is no one to speak to.")
