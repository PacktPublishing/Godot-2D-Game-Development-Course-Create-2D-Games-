extends Timer

signal BROADCAST_COMMAND(label)

var resumeWaiting:bool = true

func _ready():
	CommandDispatcher.PROCESS_COMMAND.connect(processCommand)
	CommandDispatcher.WAIT_FOR_COMMAND.connect(waitForCommand)
	CommandDispatcher.PAUSE_PROCESSOR.connect(pauseProcessor)


func processCommand(command:Command):
	if (is_stopped()):
		return
	
	stop()
	command.COMMAND_PROCESSED.connect(onCommandProcessed)
	emit_signal("BROADCAST_COMMAND", command.getCommandText())
	command.execute()


func waitForCommand():
	resumeWaiting = true
	start()
	CommandDispatcher.DISPLAY_COMMAND_PROMPT.emit()


func pauseProcessor():
	stop()
	resumeWaiting = false


func onCommandProcessed(result):
	if (result != null):
		print(result)
	
	if (resumeWaiting):
		waitForCommand()


func _on_timeout():
	processCommand(PassCommand.new())
