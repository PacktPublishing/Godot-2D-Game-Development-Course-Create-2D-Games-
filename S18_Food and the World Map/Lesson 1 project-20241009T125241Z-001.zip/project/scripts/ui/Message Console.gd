extends MarginContainer

@export var scrollContainer:ScrollContainer
@export var messages:VBoxContainer
@export var messageHistory := 10

var messageLinePrefab = preload("res://scenes/ui/MessageLine.tscn")
var messagePromptPrefab = preload("res://scenes/ui/MessagePrompt.tscn")

func _ready():
	CommandDispatcher.DISPLAY_MESSAGE.connect(_onMessageReceived)
	CommandDispatcher.DISPLAY_PROMPT.connect(_onMessagePromptReceived)
	CommandDispatcher.DISPLAY_COMMAND_PROMPT.connect(displayCommandPrompt)
	CommandDispatcher.DISPLAY_CLEAR.connect(clearWindow)

func _on_command(text):
	displayCommand(text)


func _onMessageReceived(message):
	displayMessage(message)


func _onMessagePromptReceived(text, options, callback):
	CommandDispatcher.PAUSE_PROCESSOR.emit()
	displayPrompt(text, options, callback)


func displayPrompt(text, options, callback):
	var prompt = messagePromptPrefab.instantiate()
	
	messages.add_child(prompt)
	
	prompt.messageLine.text = text
	prompt.options = options
	prompt.selectedCallback = callback
	
	scrollToEnd()


func displayCommandPrompt():
	messages.add_child(messageLinePrefab.instantiate())


func clearWindow():
	for item in messages.get_children():
		messages.remove_child(item)
		item.queue_free()


func scrollToEnd():
	await scrollContainer.get_v_scroll_bar().changed
	
	if (messages.get_child_count() > messageHistory):
		messages.get_child(0).queue_free()
	
	scrollContainer.scroll_vertical = scrollContainer.get_v_scroll_bar().max_value


func displayMessage(message):
	
	var messageLine = messageLinePrefab.instantiate()
	
	messageLine.text = "%s\n\n" % message
	
	messages.add_child(messageLine)

	scrollToEnd()


func displayCommand(message):
	
	var currentMessageLine:RichTextLabel
	
	if (messages.get_child_count() == 0):
		displayCommandPrompt()
	
	currentMessageLine = messages.get_children()[messages.get_children().size() - 1]
	
	currentMessageLine.text = currentMessageLine.text.insert(currentMessageLine.text.length() - 2, message)
	
	scrollToEnd()
