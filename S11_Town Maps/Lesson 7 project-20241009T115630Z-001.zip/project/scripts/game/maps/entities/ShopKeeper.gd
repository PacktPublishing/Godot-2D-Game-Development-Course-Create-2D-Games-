extends Mob2D

class_name ShopKeeper

@export var inventory:Array[ItemDefinition]

func interact():
	print("Welcome to my shop.")
