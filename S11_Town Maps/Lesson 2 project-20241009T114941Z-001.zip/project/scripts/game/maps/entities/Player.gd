extends Mob

class_name Player

@export var camera:Camera2D
