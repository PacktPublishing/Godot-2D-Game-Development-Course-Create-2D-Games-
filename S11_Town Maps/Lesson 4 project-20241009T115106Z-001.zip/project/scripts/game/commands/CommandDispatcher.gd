extends Node

# Command Processor Signals
signal PROCESS_COMMAND(command)
signal WAIT_FOR_COMMAND
signal PAUSE_PROCESSOR

# Game Signals
signal PLAYER_MOVE(direction)
signal PLAYER_SPEAK

# Message Console Signals
signal DISPLAY_MESSAGE(message)
signal DISPLAY_COMMAND_PROMPT
signal DISPLAY_CLEAR

signal LOAD_MAP(newMapPath, spawnpoint, facing)
signal LOAD_COMPLETE

signal TOGGLE_TILEMAP_LAYER(layerName)
