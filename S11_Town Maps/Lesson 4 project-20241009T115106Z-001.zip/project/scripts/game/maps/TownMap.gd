extends Map2d

class_name TownMap
