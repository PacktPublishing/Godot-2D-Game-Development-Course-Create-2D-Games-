extends Mob

class_name Player

@export var camera:Camera2D

func wouldCollideAt(destination):
	if (super.wouldCollideAt(destination)):
		return true
	else:
		return false
