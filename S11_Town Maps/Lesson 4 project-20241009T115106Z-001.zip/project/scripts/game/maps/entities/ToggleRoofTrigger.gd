extends MapEntity

class_name ToggleRoofTrigger

@export var layerName:String

func execute(target):
	CommandDispatcher.TOGGLE_TILEMAP_LAYER.emit(layerName)


func _on_area_entered(area):
	execute(area.get_parent())
