extends Control

class_name UI

func _on_pass_button_pressed():
	CommandDispatcher.PROCESS_COMMAND.emit(PassCommand.new())


func _on_speak_button_pressed():
	CommandDispatcher.PROCESS_COMMAND.emit(SpeakCommand.new())
