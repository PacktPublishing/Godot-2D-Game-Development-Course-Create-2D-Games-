extends Mob2D

class_name ShopKeeper

func interact():
	print("Welcome to my shop.")
