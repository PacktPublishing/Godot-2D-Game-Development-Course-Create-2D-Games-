extends Area2D

class_name MapEntity

func execute(target):
	print(target.name)


func _on_area_entered(area):
	execute(area.get_parent())
