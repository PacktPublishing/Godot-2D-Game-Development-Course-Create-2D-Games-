extends Node

var map:Map

func _ready():
	CommandDispatcher.LOAD_MAP.connect(loadMap)


func loadMap(newMapPath, spawnpoint, facing):
	var newMap:Map
	
	CommandDispatcher.PAUSE_PROCESSOR.emit()
	
	if (map != null):
		map.queue_free()
	
	map = load(newMapPath).instantiate()
	
	add_child(map)
	
	map.get_node("Entities").add_child(map.spawnPlayerAtPosition(spawnpoint, facing))
	
	GameManager.currentMap = newMapPath
	
	CommandDispatcher.WAIT_FOR_COMMAND.emit()


func _unhandled_key_input(event):
	var direction
	
	if (Input.is_action_pressed("ui_right")):
		direction = Map.Direction.East
	
	if (Input.is_action_pressed("ui_left")):
		direction = Map.Direction.West
	
	if (Input.is_action_pressed("ui_up")):
		direction = Map.Direction.North
		
	if (Input.is_action_pressed("ui_down")):
		direction = Map.Direction.South
	
	if (direction != null):
		CommandDispatcher.PROCESS_COMMAND.emit(MoveCommand.new(direction))
