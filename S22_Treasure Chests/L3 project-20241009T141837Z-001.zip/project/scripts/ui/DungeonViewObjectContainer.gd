extends Node2D

class_name DungeonViewObjectContainer

var mobRenderList:Array[Mob3D] = []
var objectRenderList:Array[Node2D] = []

func addMob(mob):
	if (!mobRenderList.has(mob)):
		mobRenderList.append(mob)


func removeMob(mob):
	mobRenderList.erase(mob)


func addObject(object):
	if (!objectRenderList.has(object)):
		objectRenderList.append(object)


func removeObject(object):
	objectRenderList.erase(object)


func updateRenderStack(map):
	updateMobRenderStack(map)
	updateObjectRenderStack(map)


func updateMobRenderStack(map):
	var distance
	var index:int = mobRenderList.size() - 1
	
	for block in get_children():
		block.get_node("Mob").hide()
		
	while index >= 0:
		if (!is_instance_valid(mobRenderList[index])):
			mobRenderList.remove_at(index)
		
		index -= 1
	
	for mob in mobRenderList:
		distance = map.player.position.distance_to(mob.position) / map.tile_set.tile_size.x
		index = DungeonView3D.MAX_VIEW_DISTANCE - distance
		get_child(index).get_node("Mob").texture = mob.sprite.texture
		get_child(index).get_node("Mob").show()


func updateObjectRenderStack(map):
	var distance
	var index:int = objectRenderList.size() - 1
	
	for block in get_children():
		block.get_node("Object").hide()
		
	while index >= 0:
		if (!is_instance_valid(objectRenderList[index])):
			objectRenderList.remove_at(index)
		
		index -= 1

	for object in objectRenderList:
		distance = map.player.position.distance_to(object.position) / map.tile_set.tile_size.x
		index = DungeonView3D.MAX_VIEW_DISTANCE - distance
		get_child(index).get_node("Object").texture = object.sprite.texture
		get_child(index).get_node("Object").modulate.a = 1.0
		get_child(index).get_node("Object").show()
