extends Mob

class_name Player3D

var facing:Map.Direction

func updateAnimation(direction):
	pass
