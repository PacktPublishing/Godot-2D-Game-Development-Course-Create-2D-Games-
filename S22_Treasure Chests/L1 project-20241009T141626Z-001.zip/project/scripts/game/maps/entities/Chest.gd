extends Node2D

class_name Chest

func open():
	pass
