extends Mob2D

class_name Player

@export var camera:Camera2D

func _ready():
	GameManager.player.FOOD_AMOUNT_CHANGED.connect(onFoodAmountChanged)

func wouldCollideAt(destination):
	if (super.wouldCollideAt(destination)):
		return true
	else:
		return false

func initializeCombatString(target) -> String:
	return combatString % target


func attack(target:Mob):
	super.attack(target)
	target.hostile = true


func onTakeDamage(amount):
	super.onTakeDamage(amount)
	GameManager.player.health = health


func onDie():
	CommandDispatcher.DISPLAY_MESSAGE.emit("You died!")
	CommandDispatcher.PAUSE_PROCESSOR.emit()
	await get_tree().create_timer(5).timeout
	GameManager.player.gold = 0
	GameManager.player.health = GameManager.player.maxHealth
	health = GameManager.player.maxHealth
	CommandDispatcher.LOAD_MAP.emit(GameManager.currentMap, null, Map.Direction.North)


func onFoodAmountChanged(amount):
	if (amount == 0):
		onDie()
