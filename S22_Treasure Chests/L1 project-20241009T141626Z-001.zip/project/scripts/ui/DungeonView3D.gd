extends Node2D

class_name DungeonView3D

const MAX_VIEW_DISTANCE = 4
enum TileIndex { EMPTY, SOLID }

@export var leftWalls:Node2D
@export var centerWalls:Node2D
@export var rightWalls:Node2D
@export var mobView:Sprite2D
@export var mobViewAnimator:AnimationPlayer

func _ready():
	CommandDispatcher.DUNGEONVIEW_MOB_FLASH.connect(onMobViewFlash)

func updateView(tilemap, player):
	var start
	var end
	var xMod = 0
	var yMod = 0
	var index = 0
	
	start = tilemap.local_to_map(player.position)

	for wall in centerWalls.get_children():
		wall.visible = false
		
	for wall in leftWalls.get_children():
		wall.visible = false
		
	for wall in rightWalls.get_children():
		wall.visible = false
		
	match(player.facing):
		Map.Direction.North:
			end = Vector2i(start.x, start.y - MAX_VIEW_DISTANCE)
			yMod = -1
		Map.Direction.South:
			end = Vector2i(start.x, start.y + MAX_VIEW_DISTANCE)
			yMod = 1
		Map.Direction.East:
			end = Vector2i(start.x + MAX_VIEW_DISTANCE, start.y)
			xMod = 1
		Map.Direction.West:
			end = Vector2i(start.x - MAX_VIEW_DISTANCE, start.y)
			xMod = -1
	
	while(start != end):
		if (xMod != 0):
			# Left wall
			if (tilemap.get_cell_atlas_coords(0, Vector2i(start.x, start.y - xMod)).x == TileIndex.SOLID):
				leftWalls.get_child(index).visible = true
				
			# Right wall
			if (tilemap.get_cell_atlas_coords(0, Vector2i(start.x, start.y + xMod)).x == TileIndex.SOLID):
				rightWalls.get_child(index).visible = true
		
			# Rear wall
			if (tilemap.get_cell_atlas_coords(0, Vector2i(start.x + xMod, start.y)).x == TileIndex.SOLID):
				centerWalls.get_child(index).visible = true
				break
				
		if (yMod != 0):
			# Left wall
			if (tilemap.get_cell_atlas_coords(0, Vector2i(start.x + yMod, start.y)).x == TileIndex.SOLID):
				leftWalls.get_child(index).visible = true
				
			# Right wall
			if (tilemap.get_cell_atlas_coords(0, Vector2i(start.x - yMod, start.y + xMod)).x == TileIndex.SOLID):
				rightWalls.get_child(index).visible = true
				
			# Rear wall
			if (tilemap.get_cell_atlas_coords(0, Vector2i(start.x, start.y + yMod)).x == TileIndex.SOLID):
				centerWalls.get_child(index).visible = true
				break
		
		start.x += xMod
		start.y += yMod
		
		index += 1


func onMobViewFlash():
	mobViewAnimator.play("flash")
