extends Node2D

class_name Chest

@export var sprite:Sprite2D

func open():
	pass
