extends Map

class_name Map3D

func spawnPlayerAtPosition(newPosition, facing):
	player = load("res://scenes/game/maps/entities/player_3d.tscn").instantiate()
	
	super.spawnPlayerAtPosition(newPosition, facing)


func onLoaded():
	CommandDispatcher.ENABLE_DUNGEON_COMMANDS.emit()
