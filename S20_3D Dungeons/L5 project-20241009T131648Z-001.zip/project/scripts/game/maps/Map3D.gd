extends Map

class_name Map3D

@export var dungeonView:DungeonView3D

func spawnPlayerAtPosition(newPosition, facing):
	player = load("res://scenes/game/maps/entities/player_3d.tscn").instantiate()
	
	super.spawnPlayerAtPosition(newPosition, facing)
	
	player.facing = facing
	
	dungeonView.updateView(self, player)


func onLoaded():
	CommandDispatcher.ENABLE_DUNGEON_COMMANDS.emit()
