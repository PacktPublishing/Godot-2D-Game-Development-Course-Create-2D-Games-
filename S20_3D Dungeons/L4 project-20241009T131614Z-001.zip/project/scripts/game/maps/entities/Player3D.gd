extends Mob

class_name Player3D
