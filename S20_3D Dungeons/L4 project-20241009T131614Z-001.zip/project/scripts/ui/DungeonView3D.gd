extends Node2D

class_name DungeonView3D

@export var leftWalls:Node2D
@export var centerWalls:Node2D
@export var rightWalls:Node2D

func updateView():
	pass
