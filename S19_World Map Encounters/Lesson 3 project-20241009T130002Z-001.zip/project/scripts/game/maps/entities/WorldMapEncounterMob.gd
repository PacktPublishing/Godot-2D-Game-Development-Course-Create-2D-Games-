extends Mob

class_name WorldMapEncounterMob

signal LEFT_ENCOUNTER

@export var sprite:Sprite2D
@export var raycast:RayCast2D

# Percentage chance the mob is friendly.
@export var friendlyChance := 10

# The player's base chance to disengage and flee.
@export var baseFleeChance := 25

# If the mob can speak, it will either offer to trade (if friendly)
# or demand payment to let you go (if not).
@export var canSpeak := false

# Edible mobs can be converted into food.
@export var edible := false

# Toxic edible mobs will (potentially) make the player sick.
@export var toxic := false

# Stuff the mob may drop when killed.
@export_group("Treasure")
@export var drops:Array[ItemDefinition]
@export var minimumGold := 10
@export var maximumGold := 100
@export var minFood := 10
@export var maxFood := 100

func _ready():
	CommandDispatcher.PROCESS_REACTIONS.connect(onReaction)
	
	hostile = randi_range(1, 100) > friendlyChance


func onReaction():
	super.onReaction()
	
	if (player.position.distance_to(position) > 16):
		position += raycast.target_position
	else:
		if (hostile):
			attack(player)


func interact():
	if (!hostile and canSpeak):
		CommandDispatcher.DISPLAY_PROMPT.emit("How you doin'?", ["Fine, thanks", "Not so hot"], onResponse)
	else:
		super.interact()


func onResponse(selection):
	match(selection):
		0:
			CommandDispatcher.DISPLAY_MESSAGE.emit("That's great!")
		1:
			CommandDispatcher.DISPLAY_MESSAGE.emit("Sorry to hear it.")
	
	LEFT_ENCOUNTER.emit()
	CommandDispatcher.WAIT_FOR_COMMAND.emit()


func onDie():
	super.onDie()
	LEFT_ENCOUNTER.emit()
