extends Node

class_name GameScreen

@export var map:Node

func _ready():
	CommandDispatcher.LOAD_MAP.emit(GameManager.currentMap, null, Map.Direction.North)

