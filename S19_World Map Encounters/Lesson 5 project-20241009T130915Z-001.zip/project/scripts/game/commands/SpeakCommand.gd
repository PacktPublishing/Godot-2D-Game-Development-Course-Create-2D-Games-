extends Command

class_name SpeakCommand

func _init():
	commandLabel = "Speak"


func execute():
	CommandDispatcher.PLAYER_SPEAK.emit()
	COMMAND_PROCESSED.emit(commandLabel)
