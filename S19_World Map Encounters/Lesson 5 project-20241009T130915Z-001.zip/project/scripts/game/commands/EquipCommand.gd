extends Command

class_name EquipCommand

var filterType:ItemDefinition.ItemTypes

func _init(filter):
	commandLabel = "Equip"
	filterType = filter


func execute():
	CommandDispatcher.SHOW_EQUIP_DIALOG.emit(filterType)
	COMMAND_PROCESSED.emit(getCommandText())


func getCommandText():
	return "%s %s" % [commandLabel, ItemDefinition.ItemTypes.keys()[filterType]]
