class_name Command

signal COMMAND_PROCESSED(label)

var commandLabel

func execute():
	COMMAND_PROCESSED.emit(commandLabel)


func getCommandText():
	return commandLabel
