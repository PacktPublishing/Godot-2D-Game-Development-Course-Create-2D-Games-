extends Command

class_name PassCommand

func _init():
	commandLabel = "Pass"


func execute():
	COMMAND_PROCESSED.emit(commandLabel)
