extends Control

class_name PlayingCard

@export var cardFace:AnimatedSprite2D

enum Suits { Hearts, Diamonds, Spades, Clubs }
enum Faces { Ace, Two, Three, Four, Five, Six, Seven, Eight, Nine, Ten, Jack, Queen, King, MISC }

const CARD_BACK:int = 27

var cardFrame:int:
	get:
		return (suit * Faces.keys().size()) + face

var suit:Suits
var face:Faces

func _ready():
	get_node("Card Face").frame = cardFrame


func flip():
	if (cardFace.frame == CARD_BACK):
		cardFace.frame = cardFrame
	else:
		cardFace.frame = CARD_BACK
