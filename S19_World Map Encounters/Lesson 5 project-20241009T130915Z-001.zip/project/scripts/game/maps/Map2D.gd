extends Map

class_name Map2D

enum TerrainDataTypes { TerrainType, FoodConsumption, EncounterChance }
	

func getTerrainDataForTile(layer, data, x, y):
	var tile:TileData = get_cell_tile_data(layer, Vector2i(x, y))

	if (tile != null):
		return tile.get_custom_data(TerrainDataTypes.keys()[data])
	else:
		return null


func spawnPlayerAtPosition(newPosition, facing):
	player = load("res://scenes/game/maps/entities/player.tscn").instantiate()
	
	super.spawnPlayerAtPosition(newPosition, facing)

	player.updateFacing(facing)

	get_node("Entities").add_child(player)


func playerCanMoveTo(newPosition:Vector2) -> bool:
	return !player.wouldCollideAt(newPosition)


func getFoodConsumptionRate() -> float:
	var tile = local_to_map(player.position)
	
	return getTerrainDataForTile(0, TerrainDataTypes.FoodConsumption, tile.x, tile.y)
