extends MapEntity

class_name ToggleRoofTrigger

@export var layerName:String

func execute(target):
	pass


func _on_area_entered(area):
	CommandDispatcher.TOGGLE_TILEMAP_LAYER.emit(layerName, false)


func _on_area_exited(area):
	CommandDispatcher.TOGGLE_TILEMAP_LAYER.emit(layerName, true)
