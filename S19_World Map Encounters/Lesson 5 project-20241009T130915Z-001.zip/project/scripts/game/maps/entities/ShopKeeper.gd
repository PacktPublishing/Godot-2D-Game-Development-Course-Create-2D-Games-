extends Mob2D

class_name ShopKeeper

signal GET_POSTAL_CODE

enum Responses { Yes, No }

@export var shopName:String
@export var inventory:Array[ItemDefinition]
@export var buybackFilter:ItemDefinition.ItemTypes
@export var mailman:bool
@export var mailQuestChance := 100
@export var mail:MailDefinition
@export var deliveryPay := 10

var nextPackageDestination:MailDefinition.Towns
var currentPostalCode:MailDefinition.Towns


func interact():
	if (mailman):
		if (currentPostalCode == MailDefinition.Towns.NO_ADDRESS):
			GET_POSTAL_CODE.emit()
		
		var deliveredMail = GameManager.player.getMail(currentPostalCode)
		
		if (deliveredMail.size() > 0):
			GameManager.player.gold += deliveredMail.size() * deliveryPay
			
			for mail in deliveredMail:
				GameManager.player.takeItem(mail)
			
			CommandDispatcher.DISPLAY_MESSAGE.emit("Thanks for the delivery!")
	
	CommandDispatcher.DISPLAY_PROMPT.emit("**%s**: Would you like to see my wares?\n\n" % shopName, Responses.keys(), onResponse)


func onResponse(selected):
	match(selected):
		Responses.Yes:
			CommandDispatcher.SHOW_SHOP_UI.emit(self, inventory, buybackFilter)
		Responses.No:
			CommandDispatcher.DISPLAY_MESSAGE.emit("Come back later, then.")
			CommandDispatcher.WAIT_FOR_COMMAND.emit()


func onLeftShop(shopUI):
	shopUI.LEFT_SHOP.disconnect(onLeftShop)
	
	if (mailman and randi_range(0, 100) <= mailQuestChance):
		nextPackageDestination = determineNextPackageDestination()
		CommandDispatcher.DISPLAY_PROMPT.emit("Would you deliver a package to %s for me?\n\n" % MailDefinition.TownNames[nextPackageDestination], Responses.keys(), onMailResponse)


func onMailResponse(response):
	match(response):
		Responses.Yes:
			var package = mail.clone()
			package.destination = nextPackageDestination
			GameManager.player.giveItem(package)
			CommandDispatcher.DISPLAY_MESSAGE.emit("Thank you!")
		Responses.No:
			CommandDispatcher.DISPLAY_MESSAGE.emit("No problem, see you again soon.")

	CommandDispatcher.WAIT_FOR_COMMAND.emit()


func determineNextPackageDestination() -> MailDefinition.Towns:
	var destination:MailDefinition.Towns
	var potentialDestinations = MailDefinition.Towns.values().duplicate()
	
	if (currentPostalCode == MailDefinition.Towns.NO_ADDRESS):
		GET_POSTAL_CODE.emit()
		
	potentialDestinations.erase(currentPostalCode)
	potentialDestinations.erase(MailDefinition.Towns.NO_ADDRESS)
	
	return potentialDestinations[randi_range(0, potentialDestinations.size() - 1)]
	
	return destination
