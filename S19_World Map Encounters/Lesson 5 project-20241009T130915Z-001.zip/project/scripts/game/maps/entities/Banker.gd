extends Mob2D

class_name Banker

@export var bankName:String

enum Responses { Yes, No }

func interact():
	CommandDispatcher.DISPLAY_PROMPT.emit("**%s**: Would you like use the bank?\n\n" % bankName, Responses.keys(), onResponse)
	

func onResponse(selection):
	match(selection):
		Responses.Yes:
			CommandDispatcher.SHOW_BANK_UI.emit(bankName)
		Responses.No:
			CommandDispatcher.DISPLAY_MESSAGE.emit("Come back later, then.")
			CommandDispatcher.WAIT_FOR_COMMAND.emit()
