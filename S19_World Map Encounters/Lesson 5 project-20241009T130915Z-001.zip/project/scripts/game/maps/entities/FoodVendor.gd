extends Mob2D

class_name FoodVendor

@export var vendorName:String
@export var price:int

enum Responses { Yes, No }

func interact():
	CommandDispatcher.DISPLAY_PROMPT.emit("**%s**: Would you like to buy some food?\n\n" % vendorName, Responses.keys(), onResponse)
	

func onResponse(selection):
	match(selection):
		Responses.Yes:
			CommandDispatcher.SHOW_FOOD_VENDOR_UI.emit(vendorName, price)
		Responses.No:
			CommandDispatcher.DISPLAY_MESSAGE.emit("Come back later, then.")
			CommandDispatcher.WAIT_FOR_COMMAND.emit()
