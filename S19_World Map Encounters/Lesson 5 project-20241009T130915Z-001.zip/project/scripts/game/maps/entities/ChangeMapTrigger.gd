extends MapEntity

class_name ChangeMapTrigger

@export_file() var map
@export var spawnpoint:Vector2i
@export var facing:Map.Direction

func execute(target):
	CommandDispatcher.LOAD_MAP.emit(map, spawnpoint, facing)
