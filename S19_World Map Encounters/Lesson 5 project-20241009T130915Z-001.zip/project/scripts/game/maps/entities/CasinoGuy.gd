extends Mob2D

class_name CasinoGuy

@export var casinoName:String
@export_file var casinoScene:String

enum Responses { Yes, No }

func interact():
	CommandDispatcher.DISPLAY_PROMPT.emit("%s: Ready to win big?" % casinoName, ["Yes", "No"], onCasinoCallback)


func onCasinoCallback(selection):
	match(selection):
		Responses.Yes:
			var casino = load(casinoScene).instantiate()
			get_tree().root.add_child(casino)
			casino.LEAVE_CASINO.connect(onLeftCasino)
			casino.casinoName.text = casinoName
		Responses.No:
			CommandDispatcher.DISPLAY_MESSAGE.emit("Your loss.")
			CommandDispatcher.WAIT_FOR_COMMAND.emit()


func onLeftCasino():
	CommandDispatcher.DISPLAY_MESSAGE.emit("Any time you got some extra gold, come on back.")
	CommandDispatcher.WAIT_FOR_COMMAND.emit()
