extends Map2D

class_name WorldMap

@export_dir var encounterTableDirectory:String

enum TerrainTypes { Grass, Forest, Swamp, Desert, Water, Mountains }

var encounterTables:Dictionary = {}

var encounter:WorldMapEncounterMob

func _ready():
	super._ready()
	
	for terrain in TerrainTypes:
		encounterTables[terrain] = (load("%s/%s.tres" % [encounterTableDirectory, terrain]))


func playerCanMoveTo(newPosition:Vector2) -> bool:
	var cast_cell_1
	var cast_cell_2
	
	player.updateRaycasts(newPosition)
	
	cast_cell_1 = local_to_map(newPosition + player.collisionRay_1.position)
	cast_cell_2 = local_to_map(newPosition + player.collisionRay_2.position)
		
	if (getTerrainDataForTile(0, TerrainDataTypes.TerrainType, cast_cell_1.x, cast_cell_1.y) != "Water" and
		getTerrainDataForTile(0, TerrainDataTypes.TerrainType, cast_cell_2.x, cast_cell_2.y) != "Water"):
		
		if (player.wouldCollideAt(newPosition)):
			CommandDispatcher.DISPLAY_MESSAGE.emit("Your path is blocked.")
			return false
		
		return true
	else:
		CommandDispatcher.DISPLAY_MESSAGE.emit("Your path is blocked.")
		return false


func onPlayerMove(direction):
	
	if (encounter == null):
		super.onPlayerMove(direction)
		
		var pos = local_to_map(player.position)
		var encounterChance = getTerrainDataForTile(0, TerrainDataTypes.EncounterChance, pos.x, pos.y)
		
		if (rng.randi_range(0, 100) <= encounterChance):
			initializeEncounter(pos)
	else:
		var newPosition = calculateNewPosition(direction)
		
		if (newPosition.distance_to(encounter.position) <= 16):
			if (player.wouldCollideAt(newPosition)):
				player.attack(encounter)
			else:
				super.onPlayerMove(direction)
				encounter.visible = true
				CommandDispatcher.DISPLAY_MESSAGE.emit("You have encountered a %s." % encounter.mobName)
		else:
			if (rng.randi_range(0, 100) <= encounter.baseFleeChance):
				CommandDispatcher.DISPLAY_MESSAGE.emit("You managed to escape the %s." % encounter.mobName)
				onEncounterMobLeft()
				onPlayerMove(direction)


func initializeEncounter(pos):
	var terrain = getTerrainDataForTile(0, TerrainDataTypes.TerrainType, pos.x, pos.y)

	var encounterDirection = rng.randi_range(0, Map.Direction.values().size() - 1)
	var encounterOffset = getEncounterDirectionOffset(encounterDirection)

	encounter = encounterTables[terrain].getEncounter()
	encounter.LEFT_ENCOUNTER.connect(onEncounterMobLeft)

	encounter.raycast.target_position = (encounterOffset * -1) / 2

	if (rng.randi_range(0, 100) <= encounter.ambushChance):
		CommandDispatcher.DISPLAY_MESSAGE.emit("You have been ambushed by a %s!" % encounter.mobName)
	else:
		encounterOffset.x = encounterOffset.x * 2
		encounterOffset.y = encounterOffset.y * 2
		encounter.visible = false
		
		CommandDispatcher.DISPLAY_MESSAGE.emit("Encounter detected from the %s." % Map.Direction.keys()[encounterDirection].to_lower())

	encounter.position = player.position + encounterOffset
	
	add_child(encounter)


func getEncounterDirectionOffset(direction) -> Vector2:
	match(direction):
		Map.Direction.North:
			return Vector2(0, -16)
		Map.Direction.South:
			return Vector2(0, 16)
		Map.Direction.East:
			return Vector2(16, 0)
		Map.Direction.West:
			return Vector2(-16, 0)

	return Vector2.ZERO


func onEncounterMobLeft():
	encounter.queue_free()
	encounter = null
