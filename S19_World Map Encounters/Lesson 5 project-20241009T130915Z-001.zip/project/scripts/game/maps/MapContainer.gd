extends Node

var map:Map
var loading:bool
var newSpawnpoint
var newFacing

func _ready():
	CommandDispatcher.LOAD_MAP.connect(loadMap)


func loadMap(newMapPath, spawnpoint, facing):
	
	CommandDispatcher.PAUSE_PROCESSOR.emit()
	
	if (map != null):
		map.queue_free()
	
	GameManager.currentMap = newMapPath
	
	loading = true
	
	ResourceLoader.load_threaded_request(GameManager.currentMap)
	
	newSpawnpoint = spawnpoint
	newFacing = facing


func _unhandled_key_input(_event):
	var direction

	if (Input.is_action_pressed("ui_right")):
		direction = Map.Direction.East
	
	if (Input.is_action_pressed("ui_left")):
		direction = Map.Direction.West
	
	if (Input.is_action_pressed("ui_up")):
		direction = Map.Direction.North
		
	if (Input.is_action_pressed("ui_down")):
		direction = Map.Direction.South
	
	if (direction != null):
		CommandDispatcher.PROCESS_COMMAND.emit(MoveCommand.new(direction))


func _process(delta):
	if (loading):
		if (ResourceLoader.load_threaded_get_status(GameManager.currentMap) == ResourceLoader.THREAD_LOAD_LOADED):
			loading = false
			
			map = ResourceLoader.load_threaded_get(GameManager.currentMap).instantiate()
			
			call_deferred("add_child", map)
			
			map.spawnPlayerAtPosition(newSpawnpoint, newFacing)
			
			CommandDispatcher.LOAD_COMPLETE.emit()
			CommandDispatcher.WAIT_FOR_COMMAND.emit()
