extends Map2D

class_name TownMap

@export var postalCode:MailDefinition.Towns

func _ready():
	var entitiesNode = get_node_or_null("Entities")
	
	if (entitiesNode != null):
		for entity in entitiesNode.get_children():
			if (entity is ShopKeeper):
				entity.GET_POSTAL_CODE.connect(getPostalCode.bind(entity))

	super._ready()


func getPostalCode(entity):
	entity.currentPostalCode = postalCode
