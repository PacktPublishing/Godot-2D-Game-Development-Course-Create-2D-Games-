extends Node

var startMap:String = "res://scenes/game/maps/world_map.tscn"

var currentMap:String

var player:PlayerData = PlayerData.new()

func startNewGame():
	currentMap = startMap
	player = PlayerData.new()
