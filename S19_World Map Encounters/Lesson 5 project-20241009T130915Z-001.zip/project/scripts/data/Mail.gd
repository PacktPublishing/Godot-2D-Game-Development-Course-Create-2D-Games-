extends Item

class_name Mail

var destination:MailDefinition.Towns:
	set(value):
		destination = value
		itemName = "%s Mail" % MailDefinition.TownNames[destination]


func _init(itemDefinition:MailDefinition):
	super._init(itemDefinition)
	
	destination = itemDefinition.destination
