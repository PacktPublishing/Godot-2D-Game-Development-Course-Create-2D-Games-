extends Resource

class_name EncounterTable

@export var commonMonsters:Array[PackedScene]
@export var uncommonMonsters:Array[PackedScene]
@export var rareMonsters:Array[PackedScene]

func getEncounter() -> WorldMapEncounterMob:
	return commonMonsters[0].instantiate() as WorldMapEncounterMob
