
class_name Item

var itemName:String
var itemType:ItemDefinition.ItemTypes
var sellPrice:int

func _init(itemDefinition:ItemDefinition):
	itemName = itemDefinition.itemName
	itemType = itemDefinition.itemType
	sellPrice = itemDefinition.price * itemDefinition.markdown
