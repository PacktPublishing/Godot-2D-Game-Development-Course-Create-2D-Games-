extends ItemDefinition

class_name MailDefinition

enum Towns { NO_ADDRESS, StarterTown, SecondCity }

const TownNames = ["No Address", "Starter Town", "Second City"]

@export var destination:Towns

func clone() -> Mail:
	return Mail.new(self)
