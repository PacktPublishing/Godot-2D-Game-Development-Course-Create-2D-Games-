extends MarginContainer

class_name ShopSellItemEntry

@export var itemName:Label
@export var itemPrice:Label
@export var sellCheckbox:CheckBox

var item:Item
