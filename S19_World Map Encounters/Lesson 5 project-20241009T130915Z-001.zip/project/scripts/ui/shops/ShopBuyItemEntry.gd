extends MarginContainer

class_name ShopBuyItemEntry

@export var itemName:Label
@export var itemPrice:Label
@export var itemQuantity:SpinBox
