extends PanelContainer

class_name EquipDialog

@export var header:Label
@export var itemsContainer:VBoxContainer

var itemEntryPrefab = preload("res://scenes/ui/EquipItemEntry.tscn")

var filter

func _on_ok_button_pressed():
	CommandDispatcher.CLOSE_DIALOG.emit(self, true)


func updateDisplay():
	var item
	
	header.text = "Equip %s" % [ItemDefinition.ItemTypes.keys()[filter]]
	
	for itemEntry in itemsContainer.get_children():
		itemEntry.queue_free()

	for itemEntry in GameManager.player.inventory:
		if (itemEntry.itemType != filter):
			continue
			
		item = itemEntryPrefab.instantiate() as Button
		item.text = itemEntry.itemName
		
		if (GameManager.player.isEquipped(itemEntry)):
			setButtonTextColors(item, Color.GREEN)
		
		item.pressed.connect(onInteract.bind(item, itemEntry))
		
		itemsContainer.add_child(item)


func onInteract(button, item):
	for otherButton in itemsContainer.get_children():
		setButtonTextColors(otherButton, Color.WHITE)
	
	if (GameManager.player.isEquipped(item)):
		GameManager.player.unequipItem(item)
		setButtonTextColors(button, Color.WHITE)
	else:
		GameManager.player.equipItem(item)
		setButtonTextColors(button, Color.GREEN)


func setButtonTextColors(button:Button, color:Color):
	button.set("theme_override_colors/font_color", color)
	button.set("theme_override_colors/font_hover_color", color)
	button.set("theme_override_colors/font_pressed_color", color)
