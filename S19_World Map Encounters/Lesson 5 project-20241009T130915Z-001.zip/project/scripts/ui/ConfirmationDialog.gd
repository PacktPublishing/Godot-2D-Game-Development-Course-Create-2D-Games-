extends Control

class_name ConfirmYesNoDialog

@export var confirmTextLabel:Label
@export var yesButton:Button
@export var noButton:Button

var yesCallback:Callable

func _on_yes_button_pressed():
	hide()
	yesCallback.call()


func _on_no_button_pressed():
	hide()
