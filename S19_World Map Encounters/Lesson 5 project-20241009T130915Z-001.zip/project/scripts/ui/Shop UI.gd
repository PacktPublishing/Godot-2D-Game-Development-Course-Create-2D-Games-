extends PanelContainer

class_name ShopUI

signal LEFT_SHOP(shopUI)

enum Modes { Buy, Sell }

var itemBuyEntryPrefab = preload("res://scenes/ui/shops/shop_buy_item_entry.tscn")
var itemSellEntryPrefab = preload("res://scenes/ui/shops/shop_sell_item_entry.tscn")

@export var shopNameLabel:Label
@export var inventoryContainerContents:VBoxContainer
@export var playerInventoryContainerContents:VBoxContainer
@export var buySellTotalAmount:Label
@export var playerGoldAmount:Label

@export var buyButton:Button
@export var sellButton:Button

var filter:ItemDefinition.ItemTypes

var mode:Modes:
	set(value):
		mode = value
		
		if (mode == Modes.Buy):
			buyButton.visible = true
			sellButton.visible = false
		else:
			buyButton.visible = false
			sellButton.visible = true
			playerInventoryItems = GameManager.player.inventory


var buySellTotalsLabelOriginalTextColor

var shopInventoryItems:Array[ItemDefinition]:
	set(value):
		var itemEntry
		
		shopInventoryItems = value
		
		for item in inventoryContainerContents.get_children():
			item.queue_free()
		
		for itemDefinition in shopInventoryItems:
			itemEntry = itemBuyEntryPrefab.instantiate() as ShopBuyItemEntry
			
			itemEntry.itemName.text = itemDefinition.itemName
			itemEntry.itemPrice.text = str(itemDefinition.price)
			
			itemEntry.itemQuantity.value_changed.connect(onSpinboxValueChanged)
			
			inventoryContainerContents.add_child(itemEntry)


var playerInventoryItems:Array[Item]:
	set(value):
		var itemEntry
		
		playerInventoryItems = value
		
		for item in playerInventoryContainerContents.get_children():
			item.queue_free()
		
		for item in playerInventoryItems:
			if (item.itemType != filter):
				continue
				
			itemEntry = itemSellEntryPrefab.instantiate() as ShopSellItemEntry
			itemEntry.itemName.text = item.itemName
			itemEntry.itemPrice.text = str(item.sellPrice)
			
			itemEntry.item = item
			
			itemEntry.sellCheckbox.pressed.connect(onSellCheckboxChanged)
			
			playerInventoryContainerContents.add_child(itemEntry)
		

func _ready():
	buySellTotalsLabelOriginalTextColor = buySellTotalAmount.get_theme_color("font_color")


func _on_buy_button_pressed():
	CommandDispatcher.SHOW_CONFIRMATION_DIALOG.emit("Buy %s items for a total of %s gold?" % [tallyBuyQuantities(), buySellTotalAmount.text], buyItems)


func _on_clear_button_pressed():
	CommandDispatcher.SHOW_CONFIRMATION_DIALOG.emit("Clear intended purchases?", clearPurchases)


func _on_leave_button_pressed():
	CommandDispatcher.SHOW_CONFIRMATION_DIALOG.emit("Leave %s?" % shopNameLabel.text, leaveShop)


func leaveShop():
	CommandDispatcher.DISPLAY_MESSAGE.emit("Thank you, come again!")
	LEFT_SHOP.emit()
	CommandDispatcher.CLOSE_DIALOG.emit(self, false)


func onSpinboxValueChanged(value):
	updateTotalPriceDisplay()


func updateTotalPriceDisplay():
	var total
	
	if (mode == Modes.Buy):
		total = tallyTotalBuyPrice()
	else:
		total = tallyTotalSellPrice()
	
	if (mode == Modes.Buy and total > GameManager.player.gold):
		buySellTotalAmount.set("theme_override_colors/font_color", Color.RED)
	else:
		buySellTotalAmount.set("theme_override_colors/font_color", buySellTotalsLabelOriginalTextColor)
		
	buySellTotalAmount.text = str(total)


func tallyTotalBuyPrice() -> int:
	var total = 0
	
	for item in inventoryContainerContents.get_children():
		total += int(item.itemPrice.text) * item.itemQuantity.value
	
	return total


func tallyBuyQuantities() -> int:
	var total = 0
	
	for item in inventoryContainerContents.get_children():
		total += item.itemQuantity.value

	return total


func buyItems():
	var totalGold = tallyTotalBuyPrice()
	
	if (GameManager.player.gold >= totalGold):
		GameManager.player.gold -= totalGold
		
		for item in inventoryContainerContents.get_children():
			for purchase in range(item.itemQuantity.value):
				GameManager.player.giveItem(shopInventoryItems[item.get_index()].clone())
		
		clearPurchases()
		
		playerGoldAmount.text = str(GameManager.player.gold)


func clearPurchases():
	if (mode == Modes.Buy):
		for item in inventoryContainerContents.get_children():
			item.itemQuantity.apply()
			item.itemQuantity.value = 0
	else:
		for item in playerInventoryContainerContents.get_children():
			item.sellCheckbox.button_pressed = false


func _on_sell_button_pressed():
	CommandDispatcher.SHOW_CONFIRMATION_DIALOG.emit("Sell %s items for a total of %s gold?" % [tallySellQuantities(), buySellTotalAmount.text], sellItems)


func _on_buy_sell_tabs_tab_changed(tab):
	mode = tab


func tallyTotalSellPrice() -> int:
	var total = 0
	
	for item in playerInventoryContainerContents.get_children():
		if (item.sellCheckbox.button_pressed):
			total += int(item.itemPrice.text)
	
	return total


func tallySellQuantities() -> int:
	var total = 0
	
	for item in playerInventoryContainerContents.get_children():
		if (item.sellCheckbox.button_pressed):
			total += 1

	return total


func onSellCheckboxChanged():
	updateTotalPriceDisplay()


func sellItems():
	var gold = tallyTotalSellPrice()
	
	GameManager.player.gold += gold
	
	for item in playerInventoryContainerContents.get_children():
		if (item.sellCheckbox.button_pressed):
			GameManager.player.takeItem(item.item)
			item.queue_free()

	buySellTotalAmount.text = str(0)
	playerGoldAmount.text = str(GameManager.player.gold)
