extends MarginContainer

class_name MessagePrompt

@export var messageLine:RichTextLabel
@export var buttonsContainer:HBoxContainer

var optionButtonPrefab = preload("res://scenes/ui/PromptButton.tscn")

var selectedCallback:Callable

var options:Array:
	set(value):
		var button
		
		options = value
		
		for option in options:
			button = optionButtonPrefab.instantiate()
			button.text = option
			
			buttonsContainer.add_child(button)
			
			button.pressed.connect(onOptionSelected.bind(buttonsContainer.get_child_count() - 1))


func onOptionSelected(option):
	selectedCallback.call(option)
