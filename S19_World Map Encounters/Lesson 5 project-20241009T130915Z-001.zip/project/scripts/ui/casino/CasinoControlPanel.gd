extends PanelContainer

class_name CasinoControlPanel

@export var controls:Control
@export var higherButton:Button
@export var lowerButton:Button
@export var guessAgainButton:Button
@export var stopGuessingButton:Button
@export var placeBetButton:Button
@export var leaveButton:Button

@export var betEntry:SpinBox
@export var statusText:Label

@export var minimumBet:int = 10
@export var maximumBet:int = 100

var defaultMaximumBetValue

func _ready():
	GameManager.player.GOLD_AMOUNT_CHANGED.connect(onPlayerGoldAmountChanged)
	
	defaultMaximumBetValue = maximumBet
	
	betEntry.min_value = minimumBet
	betEntry.max_value = maximumBet
	
	setStatusText("")
	

func onPlayerGoldAmountChanged(value):
	if (value < maximumBet):
		maximumBet = value
	else:
		maximumBet = defaultMaximumBetValue

	betEntry.max_value = maximumBet

func setStatusText(text):
	statusText.text = text


func hideAllControls():
	for control in controls.get_children():
		control.hide()


func showBettingControls():
	if (GameManager.player.gold >= minimumBet):
		placeBetButton.show()
		betEntry.show()
	else:
		statusText.text = "Come back when you can afford to bet."
		
	leaveButton.show()


func showGuessingControls():
	higherButton.show()
	lowerButton.show()


func showPushOrStopControls():
	guessAgainButton.show()
	stopGuessingButton.show()
