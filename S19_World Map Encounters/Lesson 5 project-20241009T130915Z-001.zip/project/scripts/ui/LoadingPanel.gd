extends MarginContainer

class_name LoadingPanel

@export var player:Player

func _ready():
	CommandDispatcher.LOAD_MAP.connect(onLoadMap)
	CommandDispatcher.LOAD_COMPLETE.connect(onMapLoaded)
	
	player.camera.enabled = false
	player.animator.sprite_frames.set_animation_loop("Walk Down", true)


func onLoadMap(map, spawnpoint, facing):
	player.animator.play("Walk Down")
	show()


func onMapLoaded():
	player.animator.stop()
	hide()
