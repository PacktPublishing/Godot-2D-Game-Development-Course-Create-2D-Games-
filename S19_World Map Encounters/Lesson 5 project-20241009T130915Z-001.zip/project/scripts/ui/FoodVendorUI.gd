extends PanelContainer

class_name FoodVendorUI

@export var shopName:Label
@export var playersFoodSupply:Label
@export var pricePerDay:Label
@export var playersGoldAmount:Label
@export var totalBuyPriceAmount:Label

@export var purchaseAmount:SpinBox

var defaultBuyPriceTextColor:Color

func _ready():
	GameManager.player.GOLD_AMOUNT_CHANGED.connect(onPlayerGoldAmountChanged)
	GameManager.player.FOOD_AMOUNT_CHANGED.connect(onPlayerFoodAmountChanged)
	
	defaultBuyPriceTextColor = totalBuyPriceAmount.get_theme_color("font_color")


func onPlayerGoldAmountChanged(amount):
	playersGoldAmount.text = str(amount)


func onPlayerFoodAmountChanged(amount):
	playersFoodSupply.text = str(ceil(amount))


func _on_buy_button_pressed():
	CommandDispatcher.SHOW_CONFIRMATION_DIALOG.emit("Buy %s days of food for %s gold?" % [purchaseAmount.value, totalBuyPriceAmount.text], buyFood)


func buyFood():
	var totalCost = int(totalBuyPriceAmount.text)
	
	if (totalCost <= GameManager.player.gold):
		GameManager.player.gold -= totalCost
		GameManager.player.food += purchaseAmount.value

func _on_leave_button_pressed():
	CommandDispatcher.SHOW_CONFIRMATION_DIALOG.emit("Leave %s?" % shopName.text, leaveShop)


func leaveShop():
	CommandDispatcher.DISPLAY_MESSAGE.emit("Thank you, come again!")
	CommandDispatcher.CLOSE_DIALOG.emit(self, true)


func _on_total_purchase_value_changed(value):
	var totalCost = value * int(pricePerDay.text)
	
	if (totalCost > GameManager.player.gold):
		totalBuyPriceAmount.set("theme_override_colors/font_color", Color.RED)
	else:
		totalBuyPriceAmount.set("theme_override_colors/font_color", defaultBuyPriceTextColor)

	totalBuyPriceAmount.text = str(totalCost)

