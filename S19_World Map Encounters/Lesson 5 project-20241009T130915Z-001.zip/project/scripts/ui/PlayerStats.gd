extends GridContainer

class_name PlayerStatsGrid

@export var health:Label
@export var food:Label
@export var gold:Label

func _ready():
	GameManager.player.GOLD_AMOUNT_CHANGED.connect(onGoldChanged)
	GameManager.player.FOOD_AMOUNT_CHANGED.connect(onFoodChanged)
	GameManager.player.HP_AMOUNT_CHANGED.connect(onPlayerHealthChanged)
	
	onGoldChanged(GameManager.player.gold)
	onFoodChanged(GameManager.player.food)
	onPlayerHealthChanged(GameManager.player.health)


func onGoldChanged(amount):
	gold.text = str(amount)
	
	
func onFoodChanged(amount):
	food.text = str(ceil(amount))


func onPlayerHealthChanged(amount):
	health.text = str(amount)
